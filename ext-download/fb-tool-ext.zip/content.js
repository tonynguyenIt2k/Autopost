// ========================================
// FB Multi-Post Tool - Content Script
// ========================================

// Notify the web page that the extension is installed
window.postMessage({ type: 'FB_TOOL_INSTALLED' }, '*');

// Listen for messages from the web page
window.addEventListener('message', (event) => {
  if (event.source !== window) return;

  const { type, groupId, groupUrl, content, images } = event.data;

  switch (type) {
    case 'CHECK_EXTENSION':
    case 'PING_EXTENSION':
      window.postMessage({ type: 'FB_TOOL_INSTALLED' }, '*');
      break;

    case 'START_EXTRACTION':
      chrome.runtime.sendMessage({ action: 'start_extraction' });
      break;

    case 'POST_TO_GROUP':
      if (images && images.length > 0) {
        // Use storage to pass large image data to background
        chrome.storage.local.set({ 'temp_post_images': images }, () => {
          if (chrome.runtime.lastError) {
            console.error('Storage Check Failed:', chrome.runtime.lastError);
            // Try direct send as fallback
            chrome.runtime.sendMessage({
              action: 'post_to_group',
              data: { groupId, groupUrl, content, images }
            });
          } else {
            chrome.runtime.sendMessage({
              action: 'post_to_group',
              data: { groupId, groupUrl, content, images: 'USE_STORAGE' }
            });
          }
        });
      } else {
        chrome.runtime.sendMessage({
          action: 'post_to_group',
          data: { groupId, groupUrl, content, images }
        });
      }
      break;

    case 'STOP_POSTING':
      chrome.runtime.sendMessage({ action: 'stop_posting' });
      break;

    case 'CHECK_FACEBOOK_LOGIN':
      chrome.runtime.sendMessage({ action: 'check_facebook_login' });
      break;

    case 'OPEN_FACEBOOK':
      chrome.runtime.sendMessage({ action: 'open_facebook' });
      break;

    // Page Posts Feature
    case 'SCAN_PAGE_POSTS':
      chrome.runtime.sendMessage({
        action: 'scan_page_posts',
        data: { pageUrl: event.data.pageUrl }
      });
      break;

    case 'SHARE_POST_TO_GROUP':
      chrome.runtime.sendMessage({
        action: 'share_post_to_group',
        data: {
          groupId: event.data.groupId,
          groupUrl: event.data.groupUrl,
          postUrl: event.data.postUrl
        }
      });
      break;

    case 'FETCH_USER_PAGES':
      chrome.runtime.sendMessage({ action: 'fetch_user_pages' });
      break;

    case 'GET_CURRENT_PAGE':
      chrome.runtime.sendMessage({ action: 'get_current_page' });
      break;
  }
});

// Listen for messages from the background script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const { action, data } = message;

  switch (action) {
    case 'group_data':
      window.postMessage({ type: 'GROUP_DATA', data }, '*');
      break;

    case 'status_update':
      window.postMessage({ type: 'STATUS_UPDATE', message: message.message }, '*');
      break;

    case 'total_count':
      window.postMessage({ type: 'TOTAL_COUNT', data }, '*');
      break;

    case 'FB_LOGGED_IN':
      window.postMessage({ type: 'FB_LOGGED_IN', data }, '*');
      break;

    case 'FB_USER_INFO':
      window.postMessage({ type: 'FB_USER_INFO', data }, '*');
      break;

    case 'FB_NOT_LOGGED_IN':
      window.postMessage({ type: 'FB_NOT_LOGGED_IN' }, '*');
      break;

    case 'POST_SUCCESS':
      window.postMessage({ type: 'POST_SUCCESS', data }, '*');
      break;

    case 'POST_ERROR':
      window.postMessage({ type: 'POST_ERROR', data }, '*');
      break;

    case 'error':
      window.postMessage({ type: 'ERROR', message: message.message }, '*');
      break;

    case 'complete':
      window.postMessage({ type: 'COMPLETE' }, '*');
      break;

    // Page Posts Feature
    case 'page_posts_data':
      window.postMessage({ type: 'PAGE_POSTS_DATA', data }, '*');
      break;

    case 'page_posts_complete':
      window.postMessage({ type: 'PAGE_POSTS_COMPLETE' }, '*');
      break;

    case 'SHARE_SUCCESS':
      window.postMessage({ type: 'SHARE_SUCCESS', data }, '*');
      break;

    case 'SHARE_ERROR':
      window.postMessage({ type: 'SHARE_ERROR', data }, '*');
      break;

    case 'fb_pages_data':
      window.postMessage({ type: 'FB_PAGES_DATA', data }, '*');
      break;

    case 'current_page_info':
      window.postMessage({ type: 'CURRENT_PAGE_INFO', data }, '*');
      break;
  }
});

// Ping background to check connection
chrome.runtime.sendMessage({ action: 'ping' }, (response) => {
  if (chrome.runtime.lastError) {
    console.log('FB Multi-Post Tool: Extension connection check failed');
  }
});
