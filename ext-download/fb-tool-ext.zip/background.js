// ========================================
// FB Multi-Post Tool - Background Service Worker
// ========================================

const DOC_ID = '24648931168042404';
const PAGINATION_DOC_ID = '9974006939348139';
// doc_id from fbtool.net v4.0.5 - used as fallback
const FBTOOL_DOC_ID = '9778341108915180';

// Anti-block settings
const MAX_POSTS_PER_HOUR = 15;
const MIN_DELAY_MS = 20000;  // 20 seconds
const MAX_DELAY_MS = 90000;  // 90 seconds

// State tracking
let isExtracting = false;
let isPosting = false;
let postCountThisHour = 0;
let lastHourReset = Date.now();

// Anti-block: Random delay helper
function randomDelay(min = MIN_DELAY_MS, max = MAX_DELAY_MS) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Anti-block: Rate limiting check
function checkRateLimit() {
  // Reset counter every hour
  if (Date.now() - lastHourReset > 3600000) {
    postCountThisHour = 0;
    lastHourReset = Date.now();
  }
  return postCountThisHour < MAX_POSTS_PER_HOUR;
}

// Anti-block: Checkpoint detection
function isCheckpoint(responseText) {
  if (!responseText) return false;
  return responseText.includes('checkpoint') ||
    responseText.includes('captcha') ||
    responseText.includes('temporarily blocked') ||
    responseText.includes('account has been locked');
}

// Message Listener
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  const tabId = sender.tab?.id;

  switch (request.action) {
    case 'start_extraction':
      if (!isExtracting) {
        isExtracting = true;
        startExtraction(tabId);
      }
      break;

    case 'post_to_group':
      postToGroup(tabId, request.data);
      break;

    case 'stop_posting':
      isPosting = false;
      break;

    case 'check_facebook_login':
      checkFacebookLogin(tabId);
      break;

    case 'open_facebook':
      chrome.tabs.create({ url: 'https://www.facebook.com/' }, (newTab) => {
        if (tabId) loginTrackerTabs.set(tabId, newTab.id);
      });
      break;

    // Page Posts Feature
    case 'scan_page_posts':
      scanPagePosts(tabId, request.data.pageUrl);
      break;

    case 'share_post_to_group':
      sharePostToGroup(tabId, request.data);
      break;

    case 'fetch_user_pages':
      fetchUserPages(tabId);
      break;

    case 'get_current_page':
      getCurrentPageInfo(tabId);
      break;

    case 'ping':
      sendResponse({ status: 'ok' });
      break;
  }
});

// ========================================
// Check Facebook Login Status
// ========================================
let loginTrackerTabs = new Map(); // uiTabId -> fbTabId

async function checkFacebookLogin(uiTabId) {
  try {
    const fbTabs = await chrome.tabs.query({ url: '*://*.facebook.com/*' });
    
    let userInfo = null;
    
    // 1. Try to extract user info from any active, open Facebook tabs
    if (fbTabs.length > 0) {
      for (const tab of fbTabs) {
        try {
          const info = await getUserInfoFromTab(tab.id);
          if (info && info.userId) {
            userInfo = info;
            break;
          }
        } catch (e) {
          console.log('Skipping inactive or discarded Facebook tab:', tab.id, e);
        }
      }
    }

    // 2. Fallback: Check direct c_user cookie via chrome.cookies API
    if (!userInfo) {
      try {
        const cookie = await chrome.cookies.get({ url: 'https://www.facebook.com', name: 'c_user' });
        if (cookie && cookie.value) {
          userInfo = {
            userId: cookie.value,
            userName: 'Facebook User',
            userAvatar: `https://ui-avatars.com/api/?name=FB&background=3b82f6&color=fff&size=100&bold=true&rounded=true`
          };
        }
      } catch (cookieError) {
        console.error('Error querying cookies fallback:', cookieError);
      }
    }

    if (userInfo && userInfo.userId) {
      sendMessage(uiTabId, 'FB_USER_INFO', userInfo);
    } else {
      sendMessage(uiTabId, 'FB_NOT_LOGGED_IN', null);
    }
  } catch (error) {
    sendMessage(uiTabId, 'FB_NOT_LOGGED_IN', null);
  }
}

// Track login progress for specific tabs
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url && tab.url.includes('facebook.com')) {
    for (const [uiTabId, fbTabId] of loginTrackerTabs.entries()) {
      if (tabId === fbTabId) {
        const userInfo = await getUserInfoFromTab(tabId);
        if (userInfo && userInfo.userId) {
          sendMessage(uiTabId, 'FB_USER_INFO', userInfo);
          // Close the Facebook tab since connection is successful
          try { chrome.tabs.remove(tabId); } catch (e) {}
          // Return focus to the app
          chrome.tabs.update(uiTabId, { active: true });
          chrome.tabs.get(uiTabId, (uiTab) => {
            if (uiTab && uiTab.windowId) {
              chrome.windows.update(uiTab.windowId, { focused: true });
            }
          });
          loginTrackerTabs.delete(uiTabId);
        }
      }
    }
  }
});

async function getUserInfoFromTab(tabId) {
  const result = await chrome.scripting.executeScript({
    target: { tabId: tabId },
    world: 'MAIN',
    func: () => {
      try {
        let userId = null;
        let userName = null;
        let userAvatar = null;
        let dtsg = null;
        let lsd = null;

        // --- 1. Get Auth Tokens (from FBTool 2) ---
        try {
          if (window.DTSGInitialData && window.DTSGInitialData.token) {
            dtsg = window.DTSGInitialData.token;
          }
          if (window.LSD && window.LSD.token) {
            lsd = window.LSD.token;
          }
          if (!dtsg && window.require) {
            try { dtsg = window.require("DTSGInitialData").token; } catch (e) { }
          }
          if (!lsd && window.require) {
            try { lsd = window.require("LSD").token; } catch (e) { }
          }
          if (!dtsg) {
            const input = document.querySelector('input[name="fb_dtsg"]');
            if (input) dtsg = input.value;
          }
          if (!lsd) {
            const input = document.querySelector('input[name="lsd"]');
            if (input) lsd = input.value;
          }
        } catch (e) { }

        // --- 2. Get User ID from cookie ---
        const cookies = document.cookie.split(';');
        for (const cookie of cookies) {
          const [name, value] = cookie.trim().split('=');
          if (name === 'c_user') {
            userId = value;
            break;
          }
        }

        if (!userId && !dtsg) return null;

        // --- 3. Get User Profile Info (Name & Avatar) ---
        // Strategy A: Try to get from CurrentUserInitialData (Highly robust for all profiles, pages, and businesses!)
        try {
          if (window.CurrentUserInitialData) {
            if (window.CurrentUserInitialData.NAME) {
              userName = window.CurrentUserInitialData.NAME;
            }
            if (window.CurrentUserInitialData.USER_ID) {
              userId = window.CurrentUserInitialData.USER_ID;
            }
          }
        } catch (e) {}

        // Strategy B: Try to get from aria-labels of profile links
        if (!userName) {
          const profileLink = document.querySelector('a[href*="/me/"]') ||
            document.querySelector('a[aria-label*="Trang cá nhân"]') ||
            document.querySelector('a[aria-label*="Profile"]') ||
            document.querySelector('[aria-label*="Trang cá nhân của "]') ||
            document.querySelector('[aria-label*="Profile of "]');

          if (profileLink) {
            const rawLabel = profileLink.getAttribute('aria-label');
            if (rawLabel) {
              const cleanName = rawLabel
                .replace('Trang cá nhân của ', '')
                .replace('Profile of ', '')
                .replace('Trang cá nhân: ', '')
                .replace('Trang cá nhân', '')
                .replace('Profile: ', '')
                .trim();
              if (cleanName && cleanName !== 'Trang cá nhân' && cleanName !== 'Profile' && cleanName.toLowerCase() !== 'bạn') {
                userName = cleanName;
              }
            }
          }
        }

        // Strategy B2: Try to get from avatar alt or menu aria-label (extremely robust fallback for business pages!)
        if (!userName) {
          const img = document.querySelector('img[alt*="Ảnh đại diện của "], img[alt*="Profile picture of "]');
          if (img) {
            const alt = img.getAttribute('alt');
            const cleanName = alt.replace('Ảnh đại diện của ', '').replace('Profile picture of ', '').trim();
            if (cleanName && cleanName.toLowerCase() !== 'bạn') {
              userName = cleanName;
            }
          }
        }
        if (!userName) {
          const menuBtn = document.querySelector('[aria-label*="Menu tài khoản của "], [aria-label*="Account menu for "]');
          if (menuBtn) {
            const label = menuBtn.getAttribute('aria-label');
            const cleanName = label.replace('Menu tài khoản của ', '').replace('Account menu for ', '').trim();
            if (cleanName && cleanName.toLowerCase() !== 'bạn') {
              userName = cleanName;
            }
          }
        }

        // Strategy C: Left sidebar links fallback
        if (!userName) {
          const leftSideBarLink = document.querySelector('div[role="navigation"] a[href^="https://www.facebook.com/me/"] span') ||
            document.querySelector('div[role="navigation"] a[href*="/profile.php"] span') ||
            document.querySelector('a[href*="/me/"] span') ||
            document.querySelector('a[href*="facebook.com/profile.php"] span');
          if (leftSideBarLink && leftSideBarLink.textContent) {
            userName = leftSideBarLink.textContent.trim();
          }
        }

        // Strategy D: Fallback to Page Title if on /me
        if (!userName && (window.location.pathname.includes('/me') || window.location.pathname.includes('/profile.php'))) {
          userName = document.title.replace(' | Facebook', '').trim();
        }

        const isProfileImage = (url) => {
          return url && url.includes('fbcdn.net') && !url.includes('static.') && !url.includes('/rsrc.php') && !url.includes('emoji');
        };

        const svgImages = document.querySelectorAll('image');
        for (const img of svgImages) {
          const href = img.getAttribute('xlink:href') || img.getAttribute('href');
          if (isProfileImage(href)) {
            userAvatar = href;
            break;
          }
        }

        if (!userAvatar) {
          const accountAreas = document.querySelectorAll('[aria-label*="Account"], [aria-label*="Tài khoản"], [data-pagelet*="ProfileTilesFeed"], nav, header, [role="banner"]');
          for (const area of accountAreas) {
            const imgs = area.querySelectorAll('img');
            for (const img of imgs) {
              if (isProfileImage(img.src) && img.width >= 28 && img.width <= 100) {
                userAvatar = img.src;
                break;
              }
            }
            if (userAvatar) break;
          }
        }

        // Extra Fallback Strategy: Scan all document images for a suitable avatar size
        if (!userAvatar) {
          const allImgs = document.querySelectorAll('img');
          for (const img of allImgs) {
            if (isProfileImage(img.src)) {
              const w = img.width || img.naturalWidth;
              if (w >= 28 && w <= 96) {
                userAvatar = img.src;
                break;
              }
            }
          }
        }

        if (userName && (userName.toLowerCase() === 'bạn' || userName.toLowerCase() === 'trang cá nhân của bạn')) {
          userName = 'Facebook User';
        }

        // Final Fallback: ui-avatars with exact matched profile initials
        if (!userAvatar && userName) {
          userAvatar = `https://ui-avatars.com/api/?name=${encodeURIComponent(userName || 'FB')}&background=3b82f6&color=fff&size=100&bold=true&rounded=true`;
        }

        return { userId, userName: userName || 'Facebook User', userAvatar, dtsg, lsd };
      } catch (e) {
        return null;
      }
    }
  });
  return result[0]?.result;
}

// ========================================
// Group Extraction (FBTool 2 approach - simple & reliable)
// ========================================
async function startExtraction(uiTabId) {
  let fbTabId = null;
  let isTempTab = false;
  try {
    sendMessage(uiTabId, 'status_update', 'Connecting to Facebook...');
    const connection = await getTokensResilient(uiTabId);
    if (!connection) {
      throw new Error('Could not get fb_dtsg. Please ensure you are logged into Facebook (open Facebook in a tab or log in again).');
    }
    fbTabId = connection.tabId;
    const tokens = connection.tokens;
    isTempTab = connection.isTemp;

    sendMessage(uiTabId, 'status_update', 'Tokens acquired. Starting extraction...');
    
    let cursor = null;
    let hasNextPage = true;
    let count = 0;
    const seenIds = new Set();

    while (hasNextPage && isExtracting) {
      const variables = {
        ordering: ["viewer_added"],
        scale: 1,
        count: 10
      };

      if (cursor) {
        variables.cursor = cursor;
      }

      // Determine which DocID and Friendly Name to use
      const currentDocId = cursor ? PAGINATION_DOC_ID : DOC_ID;
      const currentFriendlyName = cursor ? 'GroupsCometAllJoinedGroupsSectionPaginationQuery' : 'GroupsCometJoinsRootQuery';

      // Run the fetch INSIDE the Facebook tab context
      const responseText = await fetchGraphQLInTab(fbTabId, tokens, variables, currentDocId, currentFriendlyName);
      
      if (!responseText) {
          throw new Error('Empty response from Facebook tab.');
      }

      const response = parseResponse(responseText);

      if (response && response.errorSummary) {
        throw new Error(`Facebook error: ${response.errorSummary} (${response.errorDescription || 'Không có mô tả'})`);
      }

      if (!response || !response.data || !response.data.viewer || !response.data.viewer.all_joined_groups) {
        console.error('Invalid response structure:', response);
        throw new Error('Invalid response structure from Facebook');
      }

      const groupsData = response.data.viewer.all_joined_groups;
      
      // Extract total count if available (usually in the first response)
      if (groupsData.total_joined_groups) {
          const totalCount = groupsData.total_joined_groups;
          console.log('Total joined groups:', totalCount);
          sendMessage(uiTabId, 'total_count', totalCount);
      }

      const edges = groupsData.tab_groups_list.edges;
      
      if (edges.length > 0) {
        const newGroups = [];
        edges.forEach(edge => {
            const node = edge.node;
            if (!seenIds.has(node.id)) {
                seenIds.add(node.id);
                newGroups.push({
                    id: node.id,
                    name: node.name,
                    url: node.url,
                    image: node.profile_picture?.uri,
                    last_visited: node.viewer_last_visited_time
                });
            }
        });
        
        if (newGroups.length > 0) {
            sendMessage(uiTabId, 'group_data', newGroups);
            count += newGroups.length;
            sendMessage(uiTabId, 'status_update', `Extracted ${count} groups...`);
        }
      }

      const pageInfo = groupsData.tab_groups_list.page_info;

      if (!pageInfo.has_next_page) {
          hasNextPage = false;
      } else if (cursor === pageInfo.end_cursor) {
          console.log('Cursor did not change. Stopping.');
          hasNextPage = false;
      } else {
          hasNextPage = true;
          cursor = pageInfo.end_cursor;
      }

      if (hasNextPage) {
        const delay = Math.floor(Math.random() * 3000) + 2000;
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }

    isExtracting = false;
    sendMessage(uiTabId, 'complete', null);

  } catch (error) {
    isExtracting = false;
    sendMessage(uiTabId, 'error', error.message);
  } finally {
    if (isTempTab && fbTabId) {
      try { await chrome.tabs.remove(fbTabId); } catch(e) {}
    }
  }
}

// ========================================
// Trigger Doc ID Capture - Navigate and click composer to capture doc_id
// ========================================
async function triggerDocIdCapture(tabId, groupUrl) {
  try {
    console.log('[DocID] Triggering capture via composer click...');

    // Navigate to group first
    await chrome.tabs.update(tabId, { url: groupUrl });
    await new Promise(r => setTimeout(r, 5000)); // Wait for page load

    // Setup interception
    await setupDocIdInterception(tabId);

    // Click on composer to trigger GraphQL requests
    const result = await chrome.scripting.executeScript({
      target: { tabId: tabId },
      world: 'MAIN',
      func: async () => {
        const sleep = ms => new Promise(r => setTimeout(r, ms));

        // Find and click composer
        const composerSelectors = [
          'div[role="button"][tabindex="0"][class*="x1i10hfl"]', // General FB button
          'span[data-lexical-text="true"]', // Lexical composer
          'div[contenteditable="true"][role="textbox"]',
          'div[aria-label*="Write something"]',
          'div[aria-label*="Viết gì đó"]',
          'div[data-testid="composer-box"]',
          'div[class*="x6s0dn4"][tabindex="0"]'
        ];

        for (const sel of composerSelectors) {
          const el = document.querySelector(sel);
          if (el) {
            console.log('[DocID] Found composer element:', sel);
            el.scrollIntoView({ block: 'center' });
            await sleep(500);
            el.click();
            console.log('[DocID] Clicked composer');

            // Wait for any API calls to be made
            await sleep(2000);

            // Close any opened dialog by pressing Escape
            document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
            await sleep(500);

            return { success: true, selector: sel };
          }
        }

        return { success: false, message: 'Composer not found' };
      }
    });

    console.log('[DocID] Trigger result:', result[0]?.result);
    return result[0]?.result?.success || false;

  } catch (e) {
    console.error('[DocID] Trigger error:', e);
    return false;
  }
}

// ========================================
// Post to Group (Main Controller) - Pure GraphQL API via doc_id
// ========================================
async function postToGroup(uiTabId, data) {
  let isSuccessfulWithLink = false;
  try {
    let { groupId, groupUrl, content, images, postMode } = data;

    // Retrieve images from storage if content.js passed them via storage
    if (images === 'USE_STORAGE') {
      const storedData = await chrome.storage.local.get('temp_post_images');
      images = storedData.temp_post_images || [];
      // Clean up storage immediately
      await chrome.storage.local.remove('temp_post_images');
    }

    // Anti-block: Check rate limit
    if (!checkRateLimit()) {
      sendMessage(uiTabId, 'RATE_LIMIT_REACHED', {
        message: `⚠️ Đã đạt giới hạn ${MAX_POSTS_PER_HOUR} bài/giờ. Vui lòng đợi.`,
        postsThisHour: postCountThisHour
      });
      throw new Error(`Rate limit: ${postCountThisHour}/${MAX_POSTS_PER_HOUR} bài/giờ`);
    }

    // Verify FB tab is still alive, find one if needed
    let activeFbTabId = null;
    const storedTab = await chrome.storage.local.get('fbTabId');
    if (storedTab.fbTabId) {
      try {
        await chrome.tabs.get(storedTab.fbTabId);
        activeFbTabId = storedTab.fbTabId;
      } catch (e) {}
    }

    if (!activeFbTabId) {
      const fbTabs = await chrome.tabs.query({ url: '*://*.facebook.com/*' });
      if (fbTabs.length === 0) {
        throw new Error('Không tìm thấy tab Facebook. Vui lòng mở trang Facebook ở một tab mới.');
      }
      activeFbTabId = fbTabs[0].id;
      await chrome.storage.local.set({ fbTabId: activeFbTabId });
    }

    const imageCount = Array.isArray(images) ? images.length : 0;
    const isMobileMode = postMode === 'mobile';

    // Convert blob URLs to Base64 Data URLs to bypass Cross-Origin restrictions in the Facebook tab
    const base64Images = [];
    if (images && images.length > 0) {
        for (const url of images) {
            try {
                // If it is already a Base64 Data URL (pasted/uploaded raw base64), use it directly!
                if (typeof url === 'string' && url.startsWith('data:')) {
                    base64Images.push(url);
                    continue;
                }
                const res = await fetch(url);
                const blob = await res.blob();
                const reader = new FileReader();
                const b64 = await new Promise(r => {
                    reader.onloadend = () => r(reader.result);
                    reader.readAsDataURL(blob);
                });
                base64Images.push(b64);
            } catch(e) {
                console.error('Failed to convert image to base64:', url, e);
            }
        }
    }

    if (isMobileMode) {
      sendMessage(uiTabId, 'STATUS_UPDATE', { message: `🚀 Đăng bài bằng Mobile Mode (Mbasic) | Nội dung: ${content.length} ký tự | Ảnh: ${imageCount}` });
      await postViaMbasic(uiTabId, activeFbTabId, groupId, content, base64Images);
      isSuccessfulWithLink = true;
    } else {
      sendMessage(uiTabId, 'STATUS_UPDATE', { message: `🚀 Đăng bài bằng mô phỏng chuột (DOM Automation) | Nội dung: ${content.length} ký tự | Ảnh: ${imageCount}` });
      try {
        await postViaDOMAutomation(uiTabId, activeFbTabId, groupId, content, base64Images);
        isSuccessfulWithLink = true;
      } catch (apiError) {
        console.error('[DOMAuto] Error:', apiError);
        
        // Fallback: If DOM fails and we have NO images, try mbasic!
        if (imageCount === 0) {
          sendMessage(uiTabId, 'STATUS_UPDATE', { message: `⚠️ Lỗi DOM (${apiError.message}). Đang thử đăng dự phòng qua mbasic...` });
          await postViaMbasic(uiTabId, activeFbTabId, groupId, content, []);
          isSuccessfulWithLink = true;
        } else {
          throw apiError; 
        }
      }
    }

    // Anti-block: Increment post counter on success
    postCountThisHour++;

  } catch (error) {
    console.error('[postToGroup] Error:', error);
    sendMessage(uiTabId, 'POST_ERROR', {
      groupId: data.groupId,
      message: error.message
    });
  } finally {
    // Only return to main page if we successfully posted and retrieved the link
    if (isSuccessfulWithLink) {
      try {
        const storedTab = await chrome.storage.local.get('fbTabId');
        const activeFbTabId = storedTab.fbTabId;
        if (activeFbTabId) {
          sendMessage(uiTabId, 'STATUS_UPDATE', { message: '🏠 Quay lại trang chính Facebook để chờ đăng bài tiếp theo...' });
          await chrome.tabs.update(activeFbTabId, { url: 'https://www.facebook.com/' });
        }
      } catch (tabErr) {
        console.error('Failed to return to main page in finally:', tabErr);
      }
    }

    // Switch focus back to the AutoPost Pro tool tab (uiTabId)
    try {
      if (uiTabId) {
        sendMessage(uiTabId, 'STATUS_UPDATE', { message: '💻 Đang quay lại trang công cụ AutoPost Pro...' });
        await chrome.tabs.update(uiTabId, { active: true });
        
        // Also focus the window containing the PWA/tool
        const uiTab = await chrome.tabs.get(uiTabId);
        await chrome.windows.update(uiTab.windowId, { focused: true });
      }
    } catch (uiTabErr) {
      console.error('Failed to focus UI tab in finally:', uiTabErr);
    }
  }
}

// ========================================
// API Posting Logic (GraphQL + Media Upload)
// ========================================

async function postViaAPI(uiTabId, fbTabId, groupId, content, images, tokens) {
  try {
    let attachmentIds = [];

    // 1. Upload Images (if any)
    if (images && images.length > 0) {
      sendMessage(uiTabId, 'STATUS_UPDATE', { message: `📷 Bước 1/3: Đang tải lên ${images.length} ảnh...` });

      for (let i = 0; i < images.length; i++) {
        const b64 = images[i];
        try {
          const photoId = await uploadImage(fbTabId, groupId, b64, tokens);
          if (photoId) {
            attachmentIds.push(photoId);
            sendMessage(uiTabId, 'STATUS_UPDATE', { message: `📷 Ảnh ${i + 1}/${images.length}: Đã tải lên thành công (ID: ${photoId})` });
          }
        } catch (e) {
          console.error('Upload failed:', e);
          sendMessage(uiTabId, 'ERROR', { message: 'Lỗi tải ảnh: ' + e.message });
        }
      }
    }

    // 2. Create Post via GraphQL
    sendMessage(uiTabId, 'STATUS_UPDATE', { message: '📝 Bước 2/3: Đang tạo bài viết qua GraphQL...' });

    const uuid = () => 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
      const r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });

    const session_id = uuid();

    // DYNAMIC DOC ID RETRIEVAL (3-Strategy Approach)
    // Prioritize runtime doc_id to avoid hardcoded values
    let mutationDocId = null;
    try {
      sendMessage(uiTabId, 'STATUS_UPDATE', { message: '🔑 Đang lấy mã xác thực (doc_id) từ Facebook...' });
      const dynamicId = await getCreatePostDocId(fbTabId);
      if (dynamicId) {
        console.log('[PostAPI] ✅ Using Dynamic Doc ID:', dynamicId);
        mutationDocId = dynamicId;
        sendMessage(uiTabId, 'STATUS_UPDATE', { message: `✅ Đã lấy doc_id: ${dynamicId.slice(0, 8)}...` });
      }
    } catch (e) {
      console.warn('[PostAPI] Failed to get dynamic ID:', e);
    }

    // Fallback to fbtool.net's doc_id if dynamic retrieval fails
    if (!mutationDocId) {
      console.warn('[PostAPI] ⚠️ Using fbtool.net fallback doc_id:', FBTOOL_DOC_ID);
      mutationDocId = FBTOOL_DOC_ID;
      sendMessage(uiTabId, 'STATUS_UPDATE', { message: '⚠️ Dùng doc_id từ fbtool.net...' });
    }

    // Construct Attachments for GraphQL
    const attachments = attachmentIds.map(id => ({
      "photo": {
        "id": id,
      }
    }));

    const variables = {
      "input": {
        "composer_entry_point": "inline_composer",
        "composer_source_surface": "group",
        "composer_type": "group",
        "logging": {
          "composer_session_id": session_id
        },
        "source": "WWW_COMET_GROUP_DISCUSSION",
        "message": {
          "ranges": [],
          "text": content.replace(/\r\n/g, '\n').replace(/\r/g, '\n') // Normalize to LF only
        },
        "attachments": attachments.length > 0 ? attachments : null,
        "with_tags_ids": [],
        "inline_activities": [],
        "explicit_place_id": "0",
        "text_format_preset_id": "0",
        "tracking": [null],
        "audience": {
          "to_entity": {
            "id": groupId
          }
        },
        "actor_id": tokens.userId,
        "client_mutation_id": Math.floor(Math.random() * 1000000).toString()
      },
      "displayCommentsFeedbackContext": null,
      "displayCommentsContextEnableComment": null,
      "displayCommentsContextIsAd": null,
      "displayCommentsContextIsAggregatedShare": null,
      "displayCommentsContextIsStorySet": null,
      "feedLocation": "GROUP",
      "feedbackSource": 0,
      "focusCommentID": null,
      "gridMediaAsSizedImage": null,
      "scale": 1,
      "useDefaultActor": false,
      "UFI2CommentsProvider_commentsKey": "GroupCometComposeBoxPostMutation"
    };

    const responseText = await fetchGraphQLInTab(fbTabId, tokens, variables, mutationDocId, 'GroupCometComposeBoxPostMutation');

    if (!responseText) throw new Error('Không có phản hồi từ Server Facebook');

    // Anti-block: Check for checkpoint/captcha
    if (isCheckpoint(responseText)) {
      throw new Error('checkpoint detected - Facebook yêu cầu xác minh');
    }

    const response = parseResponse(responseText);

    // Success Check
    const postCreateResult = response && response.data && (response.data.story_create || response.data.group_post_create || response.data.group_create_post);
    
    if (postCreateResult) {
      const post = postCreateResult.post || postCreateResult.story || {};
      const postId = post.id || post.post_id || post.story_fbid || 'unknown';
      // Construct exact permalink
      const postUrl = `https://www.facebook.com/groups/${groupId}/posts/${postId}/`;

      // Cache the working doc_id for future use
      if (mutationDocId) {
        await saveDocIdToCache(mutationDocId);
      }

      sendMessage(uiTabId, 'STATUS_UPDATE', { message: `✅ Bước 3/3: Đăng bài thành công! Post ID: ${postId}` });
      sendMessage(uiTabId, 'STATUS_UPDATE', { message: `🔗 Link bài viết: ${postUrl}` });
      sendMessage(uiTabId, 'POST_SUCCESS', { groupId, postId, postLink: postUrl });
      return;
    }

    // Error Check - clear cache as doc_id might be expired
    if (response && response.errors) {
      await clearDocIdCache(); // Doc ID might be expired
      throw new Error(response.errors[0]?.message || 'Lỗi GraphQL');
    }

    // Check for silent data null
    if (response && response.data === null) {
      console.error('GraphQL Data Null:', response);
      await clearDocIdCache(); // Doc ID might be expired
      throw new Error('Facebook từ chối yêu cầu (Data is null) - doc_id có thể hết hạn');
    }

    // Debug: Log what we received
    console.error('[PostAPI] Unexpected response structure:');
    console.error('Response text (first 500 chars):', responseText?.substring(0, 500));
    console.error('Parsed response:', JSON.stringify(response, null, 2)?.substring(0, 500));

    // Try to extract any error message from response
    let errorMsg = 'Lỗi không xác định (API Response Unknown)';
    if (!response) {
      errorMsg = `Không thể phân tích phản hồi từ Facebook: ${responseText ? responseText.substring(0, 100) : 'Rỗng'}`;
    } else if (response.errorSummary) {
      errorMsg = `${response.errorSummary} - ${response.errorDescription || ''}`;
    } else if (response.error?.message) {
      errorMsg = response.error.message;
    } else if (response.error && typeof response.error === 'object') {
      errorMsg = `Lỗi hệ thống FB: ${response.error.errorSummary || response.error.description || JSON.stringify(response.error)}`;
    } else if (response.data?.error) {
      errorMsg = response.data.error.message || JSON.stringify(response.data.error);
    } else if (typeof response === 'string') {
      errorMsg = 'Response dạng text: ' + response.substring(0, 100);
    }

    await clearDocIdCache(); // Clear cache on unknown error
    throw new Error(errorMsg);

  } catch (e) {
    throw e;
  }
}

async function uploadImage(tabId, groupId, base64Data, tokens) {
  const result = await chrome.scripting.executeScript({
    target: { tabId: tabId },
    world: 'MAIN',
    args: [groupId, base64Data, tokens],
    func: async (groupId, base64Data, tokens) => {
      try {
        // Convert Base64 to File Object
        const byteCharacters = atob(base64Data.split(',')[1]);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], { type: 'image/jpeg' });
        const file = new File([blob], "image.jpg", { type: "image/jpeg" });

        const formData = new FormData();
        formData.append('source', '8');
        formData.append('profile_id', tokens.userId);
        formData.append('target_id', groupId);
        formData.append('file', file);
        formData.append('fb_dtsg', tokens.dtsg);
        formData.append('av', tokens.userId);

        // Upload Endpoint
        const response = await fetch('https://upload.facebook.com/ajax/react_composer/attachments/photo/upload', {
          method: 'POST',
          body: formData
        });

        const text = await response.text();
        // Strip protection chars
        const jsonText = text.replace('for (;;);', '');
        const json = JSON.parse(jsonText);

        return json.payload?.photoID || null;
      } catch (e) {
        console.error('Upload Error helper:', e);
        return null;
      }
    }
  });
  return result[0]?.result;
}

// ========================================
// Helper Functions
// ========================================
function sendMessage(tabId, action, data) {
  chrome.tabs.sendMessage(tabId, { action, data, message: data });
}

function parseResponse(text) {
    if (!text) return null;
    try {
        let cleanText = text.trim();
        if (cleanText.startsWith('for (;;);')) {
            cleanText = cleanText.substring(9).trim();
        }
        
        const lines = cleanText.split('\n').filter(line => line.trim());
        if (lines.length > 0) {
            for (let line of lines) {
                line = line.trim();
                if (line.startsWith('for (;;);')) {
                    line = line.substring(9).trim();
                }
                try {
                    const json = JSON.parse(line);
                    if (json.data) return json;
                    if (json.errors) console.error('GraphQL Errors:', json.errors);
                    if (json.errorSummary || json.error) return json;
                } catch (e) {}
            }
            try {
                let firstLine = lines[0].trim();
                if (firstLine.startsWith('for (;;);')) {
                    firstLine = firstLine.substring(9).trim();
                }
                return JSON.parse(firstLine);
            } catch(e) {}
        }
        return JSON.parse(cleanText);
    } catch (e) {
        console.error('Parse error:', e, 'Response text preview:', text.substring(0, 300));
        return null;
    }
}

async function getTokensFromTab(tabId) {
    const result = await chrome.scripting.executeScript({
        target: { tabId: tabId },
        world: 'MAIN',
        func: async () => {
          let d = null;
          let l = null;
          let u = null;
          // Poll for DTSG for up to 5 seconds (25 iterations * 200ms)
          for (let i = 0; i < 25; i++) {
            try {
              if (window.DTSGInitialData && window.DTSGInitialData.token) {
                d = window.DTSGInitialData.token;
              }
              if (!d && window.DTSGInitData && window.DTSGInitData.token) {
                d = window.DTSGInitData.token;
              }
              if (window.LSD && window.LSD.token) {
                  l = window.LSD.token;
              }
              if (!d && window.require) {
                  try { d = window.require("DTSGInitialData").token; } catch(e) {}
                  try { if (!d) d = window.require("DTSGInitData").token; } catch(e) {}
              }
              if (!l && window.require) {
                  try { l = window.require("LSD").token; } catch(e) {}
              }
              if (!d) {
                  const input = document.querySelector('input[name="fb_dtsg"]');
                  if (input) d = input.value;
              }
              if (!l) {
                  const input = document.querySelector('input[name="lsd"]');
                  if (input) l = input.value;
              }
              
              // Extract user ID
              try {
                if (window.CurrentUserInitialData && window.CurrentUserInitialData.USER_ID) {
                  u = window.CurrentUserInitialData.USER_ID;
                }
              } catch (e) {}
              if (!u) {
                const cookies = document.cookie.split(';');
                for (const cookie of cookies) {
                  const [name, value] = cookie.trim().split('=');
                  if (name === 'c_user') {
                    u = value;
                    break;
                  }
                }
              }
            } catch (e) {}
            
            if (d) {
              return { dtsg: d, lsd: l, userId: u };
            }
            // Wait 200ms
            await new Promise(r => setTimeout(r, 200));
          }
          return { dtsg: null, lsd: null, userId: null };
        }
    });
    return result[0]?.result;
}

async function isTabActiveAndReady(tabId) {
  try {
    const tab = await chrome.tabs.get(tabId);
    if (tab.discarded) {
      console.warn(`[isTabActiveAndReady] Tab ${tabId} is discarded.`);
      return false;
    }
    const ready = tab.status === 'complete' && tab.url && tab.url.includes('facebook.com');
    console.log(`[isTabActiveAndReady] Tab ${tabId} status=${tab.status} url=${tab.url} ready=${ready}`);
    return ready;
  } catch (e) {
    console.error(`[isTabActiveAndReady] Error checking tab ${tabId}:`, e);
    return false;
  }
}

function extractTokensFromHtml(html) {
  let dtsg = null;
  let lsd = null;
  let userId = null;
  try {
    let match = html.match(/"DTSGInitialData"\s*,\s*\[\]\s*,\s*{\s*"token"\s*:\s*"([^"]+)"/);
    if (match) {
      dtsg = match[1];
    }
    if (!dtsg) {
      match = html.match(/"DTSGInitData"\s*,\s*\[\]\s*,\s*{\s*"token"\s*:\s*"([^"]+)"/);
      if (match) dtsg = match[1];
    }
    if (!dtsg) {
      match = html.match(/"DTSGInitData"\s*,\s*{\s*"token"\s*:\s*"([^"]+)"/);
      if (match) dtsg = match[1];
    }
    if (!dtsg) {
      match = html.match(/"token"\s*:\s*"(AQ[^"]+)"/);
      if (match) dtsg = match[1];
    }
    if (!dtsg) {
      match = html.match(/name="fb_dtsg"\s*value="([^"]+)"/) || html.match(/value="([^"]+)"\s*name="fb_dtsg"/);
      if (match) dtsg = match[1];
    }
    match = html.match(/"LSD"\s*,\s*\[\]\s*,\s*{\s*"token"\s*:\s*"([^"]+)"/);
    if (match) {
      lsd = match[1];
    } else {
      match = html.match(/name="lsd"\s*value="([^"]+)"/) || html.match(/value="([^"]+)"\s*name="lsd"/);
      if (match) lsd = match[1];
    }
    
    // Extract userId
    match = html.match(/"USER_ID"\s*:\s*"(\d+)"/) || html.match(/"c_user"\s*:\s*"(\d+)"/) || html.match(/db_profile_id\s*:\s*"(\d+)"/);
    if (match) userId = match[1];
    if (!userId) {
      const cUserMatch = html.match(/c_user=(\d+)/);
      if (cUserMatch) userId = cUserMatch[1];
    }
  } catch (e) {
    console.error('Error extracting tokens from HTML:', e);
  }
  return { dtsg, lsd, userId };
}

async function getTokensResilient(uiTabId) {
  if (uiTabId) sendMessage(uiTabId, 'status_update', '🔍 Kiểm tra các tab Facebook đang mở...');
  const fbTabs = await chrome.tabs.query({ url: '*://*.facebook.com/*' });
  
  // 1. Try existing tabs first
  if (fbTabs.length > 0) {
    if (uiTabId) sendMessage(uiTabId, 'status_update', `Tìm thấy ${fbTabs.length} tab Facebook. Đang trích xuất token...`);
    for (const tab of fbTabs) {
      try {
        const isReady = await isTabActiveAndReady(tab.id);
        if (!isReady) {
          console.warn(`Tab ${tab.id} is not active/ready (likely discarded or loading). Skipping.`);
          continue;
        }
        const tokens = await getTokensFromTab(tab.id);
        if (tokens && tokens.dtsg) {
          if (uiTabId) sendMessage(uiTabId, 'status_update', '✅ Đã lấy token bảo mật từ tab có sẵn.');
          return { tokens, tabId: tab.id, isTemp: false };
        }
      } catch (e) {
        console.warn('Failed to extract tokens from existing tab:', tab.id, e);
      }
    }
  }
  
  // 2. Fetch www.facebook.com directly in the background (silent fallback)
  if (uiTabId) sendMessage(uiTabId, 'status_update', 'Đang trích xuất token ngầm qua API...');
  try {
    const response = await fetch('https://www.facebook.com/', {
      headers: {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
        'cache-control': 'no-cache',
        'pragma': 'no-cache'
      },
      credentials: 'include'
    });
    if (response.ok) {
      const html = await response.text();
      const tokens = extractTokensFromHtml(html);
      if (tokens && tokens.dtsg) {
        if (uiTabId) sendMessage(uiTabId, 'status_update', '✅ Đã lấy token qua API ngầm.');
        
        // Try to find an already-open, ready Facebook tab to reuse
        const openTabs = await chrome.tabs.query({ url: '*://*.facebook.com/*' });
        let targetTabId = null;
        for (const tab of openTabs) {
          if (await isTabActiveAndReady(tab.id)) {
            targetTabId = tab.id;
            break;
          }
        }
        
        if (targetTabId) {
          return { tokens, tabId: targetTabId, isTemp: false };
        } else {
          // No active/ready tab found, but we retrieved tokens. Let's create a temporary background tab!
          if (uiTabId) sendMessage(uiTabId, 'status_update', '⚠️ Đang mở tab Facebook ngầm để làm môi trường gọi API...');
          try {
            const tempTab = await chrome.tabs.create({ url: 'https://www.facebook.com/', active: false });
            await waitForPageLoad(tempTab.id, 8000);
            return { tokens, tabId: tempTab.id, isTemp: true };
          } catch (tabError) {
            console.error('Failed to create background tab:', tabError);
            if (uiTabId) sendMessage(uiTabId, 'status_update', '⚠️ Không thể mở tab ngầm, buộc dùng service worker trực tiếp.');
            return { tokens, tabId: null, isTemp: false };
          }
        }
      }
    }
  } catch (fetchError) {
    console.error('Silent background token fetch failed:', fetchError);
  }

  // 3. SECOND SILENT FALLBACK: Fetch mbasic.facebook.com (extremely lightweight and reliable on mobile/desktop)
  if (uiTabId) sendMessage(uiTabId, 'status_update', 'Đang trích xuất token ngầm qua mbasic...');
  try {
    const mbasicResponse = await fetch('https://mbasic.facebook.com/', {
      headers: {
        'upgrade-insecure-requests': '1',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'cache-control': 'no-cache',
        'pragma': 'no-cache'
      },
      credentials: 'include'
    });
    if (mbasicResponse.ok) {
      const mbasicHtml = await mbasicResponse.text();
      const tokens = extractTokensFromHtml(mbasicHtml);
      if (tokens && tokens.dtsg) {
        if (uiTabId) sendMessage(uiTabId, 'status_update', '✅ Đã lấy token qua mbasic ngầm.');
        
        // Find existing ready tab to reuse if any
        const openTabs = await chrome.tabs.query({ url: '*://*.facebook.com/*' });
        let targetTabId = null;
        for (const tab of openTabs) {
          if (await isTabActiveAndReady(tab.id)) {
            targetTabId = tab.id;
            break;
          }
        }
        return { tokens, tabId: targetTabId, isTemp: false };
      }
    }
  } catch (mbasicError) {
    console.error('Silent background mbasic token fetch failed:', mbasicError);
  }
  
  // 4. LAST RESORT FALLBACK: Open a foreground tab (active: true) as a last resort
  if (uiTabId) sendMessage(uiTabId, 'status_update', '⚠️ Đang mở tab Facebook chính để lấy token bảo mật...');
  try {
    const newTab = await chrome.tabs.create({ url: 'https://www.facebook.com/', active: true });
    if (uiTabId) sendMessage(uiTabId, 'status_update', 'Chờ trang Facebook tải xong (tối đa 8 giây)...');
    await waitForPageLoad(newTab.id, 8000);
    if (uiTabId) sendMessage(uiTabId, 'status_update', 'Đang trích xuất token bảo mật...');
    const tokens = await getTokensFromTab(newTab.id);
    if (tokens && tokens.dtsg) {
      if (uiTabId) sendMessage(uiTabId, 'status_update', '✅ Lấy token từ tab Facebook thành công.');
      return { tokens, tabId: newTab.id, isTemp: true };
    } else {
      if (uiTabId) sendMessage(uiTabId, 'status_update', '❌ Không thể lấy token từ tab Facebook.');
      try { await chrome.tabs.remove(newTab.id); } catch(e) {}
    }
  } catch (tabCreateError) {
    console.error('Failed to create foreground tab for tokens:', tabCreateError);
  }
  
  return null;
}

async function fetchGraphQLInTab(tabId, tokens, variables, docId, friendlyName) {
    const swHeaders = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.9,vi;q=0.8',
        'Origin': 'https://www.facebook.com',
        'Referer': 'https://www.facebook.com/',
        'X-FB-Friendly-Name': friendlyName,
        'X-FB-LSD': tokens.lsd || '',
        'X-ASBD-ID': '129477',
        'X-FB-HTTP-Engine': 'Liger',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Dest': 'empty'
    };

    if (!tabId) {
        // Run GraphQL fetch directly in the background service worker.
        const body = new URLSearchParams();
        body.append('fb_dtsg', tokens.dtsg);
        if (tokens.lsd)  body.append('lsd', tokens.lsd);
        if (tokens.userId) body.append('__user', tokens.userId);
        body.append('__a', '1');
        body.append('__req', Math.random().toString(36).slice(2, 6));
        body.append('doc_id', docId);
        body.append('variables', JSON.stringify(variables));
        body.append('fb_api_caller_class', 'RelayModern');
        body.append('fb_api_req_friendly_name', friendlyName);
        body.append('server_timestamps', 'true');

        try {
            const response = await fetch('https://www.facebook.com/api/graphql/', {
                method: 'POST',
                headers: swHeaders,
                body: body,
                credentials: 'include'
            });
            const text = await response.text();
            if (!response.ok) {
                throw new Error(`SW Fetch HTTP ${response.status}: ${text.slice(0, 100)}`);
            }
            return text || null;
        } catch (e) {
            throw new Error(`Service Worker fetch error: ${e.message}`);
        }
    }

    let tabResult = null;
    let tabError = null;

    try {
        const result = await chrome.scripting.executeScript({
            target: { tabId: tabId },
            args: [tokens, variables, docId, friendlyName],
            func: async (tokens, variables, docId, friendlyName) => {
                const body = new URLSearchParams();
                body.append('fb_dtsg', tokens.dtsg);
                if (tokens.lsd) body.append('lsd', tokens.lsd);
                if (tokens.userId) body.append('__user', tokens.userId);
                body.append('__a', '1');
                body.append('__req', Math.random().toString(36).slice(2, 6));
                body.append('doc_id', docId);
                body.append('variables', JSON.stringify(variables));
                body.append('fb_api_caller_class', 'RelayModern');
                body.append('fb_api_req_friendly_name', friendlyName);
                body.append('server_timestamps', 'true');

                try {
                    const response = await fetch('https://www.facebook.com/api/graphql/', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                            'Accept': '*/*',
                            'X-FB-Friendly-Name': friendlyName,
                            'X-FB-LSD': tokens.lsd || ''
                        },
                        body: body,
                        credentials: 'include'
                    });
                    const txt = await response.text();
                    if (!response.ok) {
                        return { error: `HTTP ${response.status}: ${txt.slice(0, 100)}` };
                    }
                    return txt;
                } catch (e) {
                    return { error: e.message || String(e) };
                }
            }
        });
        tabResult = result[0]?.result;
        if (tabResult && typeof tabResult === 'object' && tabResult.error) {
            tabError = tabResult.error;
            tabResult = null;
        }
    } catch (e) {
        tabError = e.message || String(e);
        tabResult = null;
    }
    
    if (!tabResult) {
        console.warn('[fetchGraphQLInTab] Tab script returned null. Falling back to service worker fetch. Tab Error:', tabError);
        const body = new URLSearchParams();
        body.append('fb_dtsg', tokens.dtsg);
        if (tokens.lsd) body.append('lsd', tokens.lsd);
        if (tokens.userId) body.append('__user', tokens.userId);
        body.append('__a', '1');
        body.append('__req', Math.random().toString(36).slice(2, 6));
        body.append('doc_id', docId);
        body.append('variables', JSON.stringify(variables));
        body.append('fb_api_caller_class', 'RelayModern');
        body.append('fb_api_req_friendly_name', friendlyName);
        body.append('server_timestamps', 'true');
        try {
            const response = await fetch('https://www.facebook.com/api/graphql/', {
                method: 'POST',
                headers: swHeaders,
                body: body,
                credentials: 'include'
            });
            const text = await response.text();
            if (!response.ok) {
                throw new Error(`SW Fallback HTTP ${response.status}. Tab Error: ${tabError}`);
            }
            if (!text) {
                throw new Error(`SW Fallback empty response. Tab Error: ${tabError}`);
            }
            return text;
        } catch (e) {
            throw new Error(`Fallback failed: ${e.message}. Tab Error: ${tabError}`);
        }
    }
    
    return tabResult;
}

// ========================================
// Page Posts Feature - Scan Posts from a Page (mbasic approach - NO tab redirects)
// ========================================
async function scanPagePosts(uiTabId, pageUrl) {
  let fbTabId = null;
  let isTempTab = false;
  try {
    sendMessage(uiTabId, 'status_update', 'Đang kết nối để lấy thông tin Trang...');

    // Ensure we are fetching the WWW version
    let fetchUrl = pageUrl;
    try {
      const urlObj = new URL(pageUrl);
      if (urlObj.hostname.includes('mbasic')) {
        urlObj.hostname = 'www.facebook.com';
      }
      fetchUrl = urlObj.toString();
    } catch (e) { }

    sendMessage(uiTabId, 'status_update', 'Đang lấy access tokens...');
    const connection = await getTokensResilient(uiTabId);
    if (!connection) {
      throw new Error('Không thể lấy fb_dtsg. Vui lòng đảm bảo bạn đã đăng nhập Facebook.');
    }
    fbTabId = connection.tabId;
    const tokens = connection.tokens;
    isTempTab = connection.isTemp;

    // Fetch the URL to get the Page ID primarily.
    let html = '';
    try {
      const response = await fetch(fetchUrl, {
        headers: {
          'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
          'accept-language': 'en-US,en;q=0.9,vi;q=0.8',
          'cache-control': 'max-age=0',
          'sec-fetch-dest': 'document',
          'sec-fetch-mode': 'navigate',
          'sec-fetch-site': 'same-origin',
          'upgrade-insecure-requests': '1'
        },
        credentials: 'include'
      });
      if (response.ok) {
        html = await response.text();
      }
    } catch (e) {
      console.error('Background fetch failed:', e);
    }

    if (!html) {
      sendMessage(uiTabId, 'status_update', '⚠️ Không thể tải trang WWW (CORS/Lỗi mạng hoặc bị chặn).');
      return;
    }

    // Search for pageID from the HTML.
    let pageId = null;
    const regexes = [
      /"pageID":"(\d+)"/,
      /"identifier":(\d+)/,
      /"profile_id":(\d+)/,
      /"entity_id":"(\d+)"/,
      /"delegate_page":{"id":"(\d+)"}/
    ];

    for (const regex of regexes) {
      const match = regex.exec(html);
      if (match) {
        pageId = match[1];
        break;
      }
    }

    if (!pageId) {
      try {
        const u = new URL(fetchUrl);
        const idParam = u.searchParams.get('id');
        if (idParam) pageId = idParam;
      } catch (e) { }
    }

    if (!pageId) {
      sendMessage(uiTabId, 'status_update', '⚠️ Không thể tìm thấy ID của Trang từ URL này.');
      return;
    }

    sendMessage(uiTabId, 'status_update', `Đã tìm thấy ID Trang: ${pageId}. Đang quét bài viết qua GraphQL API...`);

    const variables = {
      "count": 5,
      // Removed cursor completely to let Facebook serve the first page timeline
      "feedLocation": "TIMELINE",
      "feedbackSource": 0,
      "focusCommentID": null,
      "memorializedSplitTimeFilter": null,
      "omitPinnedPost": true,
      "postedBy": { "group": "OWNER" },
      "privacy": null,
      "privacySelectorRenderLocation": "COMET_STREAM",
      "referringStoryRenderLocation": null,
      "renderLocation": "timeline",
      "scale": 1,
      "stream_count": 1,
      "taggedInOnly": null,
      "trackingCode": null,
      "useDefaultActor": false,
      "id": pageId,
      "__relay_internal__pv__GHLShouldChangeAdIdFieldNamerelayprovider": true,
      "__relay_internal__pv__GHLShouldChangeSponsoredDataFieldNamerelayprovider": true,
      "__relay_internal__pv__CometFeedStory_enable_post_permalink_white_space_clickrelayprovider": false,
      "__relay_internal__pv__CometUFICommentActionLinksRewriteEnabledrelayprovider": false,
      "__relay_internal__pv__CometUFICommentAvatarStickerAnimatedImagerelayprovider": false,
      "__relay_internal__pv__IsWorkUserrelayprovider": false,
      "__relay_internal__pv__TestPilotShouldIncludeDemoAdUseCaserelayprovider": false,
      "__relay_internal__pv__FBReels_deprecate_short_form_video_context_gkrelayprovider": true,
      "__relay_internal__pv__FBReels_enable_view_dubbed_audio_type_gkrelayprovider": true,
      "__relay_internal__pv__CometImmersivePhotoCanUserDisable3DMotionrelayprovider": false,
      "__relay_internal__pv__WorkCometIsEmployeeGKProviderrelayprovider": false,
      "__relay_internal__pv__IsMergQAPollsrelayprovider": false,
      "__relay_internal__pv__FBReelsMediaFooter_comet_enable_reels_ads_gkrelayprovider": true,
      "__relay_internal__pv__CometUFIReactionsEnableShortNamerelayprovider": false,
      "__relay_internal__pv__CometUFICommentAutoTranslationTyperelayprovider": "ORIGINAL",
      "__relay_internal__pv__CometUFIShareActionMigrationrelayprovider": true,
      "__relay_internal__pv__CometUFISingleLineUFIrelayprovider": false,
      "__relay_internal__pv__CometUFI_dedicated_comment_routable_dialog_gkrelayprovider": true,
      "__relay_internal__pv__FBReelsIFUTileContent_reelsIFUPlayOnHoverrelayprovider": true,
      "__relay_internal__pv__GroupsCometGYSJFeedItemHeightrelayprovider": 206,
      "__relay_internal__pv__ShouldEnableBakedInTextStoriesrelayprovider": false,
      "__relay_internal__pv__StoriesShouldIncludeFbNotesrelayprovider": false
    };

    const docId = '26812437018342608';

    // The friendlyName isn't strictly enforced by Facebook but useful for debugging
    const friendlyName = 'ProfileCometTimelineFeedRefetchQuery';

    const responseText = await fetchGraphQLInTab(fbTabId, tokens, variables, docId, friendlyName);

    if (!responseText) {
      throw new Error('Phản hồi rỗng từ API GraphQL.');
    }

    // Parse all chunks because FB GraphQL streams NDJSON with @defer
    let cleanText = responseText.trim();
    if (cleanText.startsWith('for (;;);')) {
      cleanText = cleanText.substring(9);
    }
    const allResponses = [];
    const lines = cleanText.split('\n').filter(l => l.trim());
    for (const line of lines) {
      try {
        allResponses.push(JSON.parse(line));
      } catch (e) { }
    }

    // Pass the entire array of responses to traverse
    const response = allResponses;

    const extractedPosts = [];

    // Utility function to traverse deeply and extract nodes that look like a story Post
    const traverse = (obj, predicate) => {
      let results = [];
      const dfs = (current) => {
        if (!current || typeof current !== 'object') return;
        if (predicate(current)) {
          results.push(current);
        }
        if (Array.isArray(current)) {
          current.forEach(dfs);
        } else {
          try {
            Object.values(current).forEach(dfs);
          } catch (e) { }
        }
      };
      dfs(obj);
      return results;
    };

    // Typical nodes have post_id directly when they are Story nodes
    const allStories = traverse(response, (node) => {
      if (!node || typeof node !== 'object') return false;
      if (node.__typename === 'Story') return true;
      if (node.comet_sections && node.comet_sections.content && node.comet_sections.content.story) return true;
      if (node.post_id || node.story_fbid) return true;
      if (node.message && node.message.text && (node.url || node.id)) return true;
      return false;
    });

    sendMessage(uiTabId, 'status_update', `🔍 Debug: Đã nhận ${allResponses.length} GraphQL chunks. Tìm thấy ${allStories.length} đối tượng Story thô.`);

    const seenIds = new Set();

    // Normalizing story objects if they are nested
    const normalizedStories = allStories.map(s => {
      if (s.__typename === 'Story') return s;
      if (s.comet_sections?.content?.story) return s.comet_sections.content.story;
      return s;
    }).filter(s => s && typeof s === 'object');

    if (normalizedStories.length > 0) {
      for (const story of normalizedStories) {
        if (extractedPosts.length >= 5) break;

        let postId = story.post_id || story.story_fbid;

        // If no post_id, attempt to extract from id or url
        if (!postId && story.url) {
          const urlMatch = /\/(?:posts|videos|photos|pfbid0.*?)\/([a-zA-Z0-9_]+)/.exec(story.url);
          if (urlMatch) postId = urlMatch[1];
        }

        if (!postId && story.id) {
          try {
            const decodedId = atob(story.id); // e.g. "Story_12345"
            const idMatch = decodedId.match(/\d+/);
            if (idMatch) postId = idMatch[0];
          } catch (e) { }
        }

        if (!postId && story.shareable_from_preferences && story.shareable_from_preferences.share_link) {
          const link = story.shareable_from_preferences.share_link;
          const urlMatch = /(?:fbid=|\/posts\/|\/videos\/|\/photos\/)([0-9a-zA-Z_]+)/.exec(link);
          if (urlMatch) postId = urlMatch[1];
        }

        if (!postId || seenIds.has(postId)) continue;
        seenIds.add(postId);

        let text = '[Bài viết rỗng hoặc chứa Video/Link]';
        let media = null;
        let time = 'Mới đăng';

        if (story.message && story.message.text) {
          text = story.message.text;
        } else if (story.attachments && story.attachments.length > 0) {
          // try to find text inside attachment if message is empty
          const attachMsg = traverse(story.attachments, n => n && n.message && n.message.text);
          if (attachMsg.length > 0) text = attachMsg[0].message.text;
        }

        const images = traverse(story, (n) => n && n.uri && typeof n.uri === 'string' && (n.uri.includes('scontent') || n.uri.includes('fbcdn') || n.uri.includes('fb_external_a')));
        if (images.length > 0) {
          // Look for highest resolution or first valid image. We filter out small icons.
          const bigImages = images.filter(img => !img.uri.includes('/safe_image.php') || img.uri.includes('url='));
          media = bigImages.length > 0 ? bigImages[0].uri : images[0].uri;
        }

        if (story.creation_time) {
          time = new Date(story.creation_time * 1000).toLocaleString('vi-VN');
        }

        const postUrl = story.url || `https://www.facebook.com/${postId}`;

        extractedPosts.push({
          id: postUrl,
          url: postUrl,
          text: text.length > 300 ? text.substring(0, 300) + '...' : text,
          media: media,
          type: media ? 'image' : 'text',
          time: time
        });
      }
    }

    if (extractedPosts.length > 0) {
      sendMessage(uiTabId, 'page_posts_data', extractedPosts);
      sendMessage(uiTabId, 'status_update', `✅ Đã tìm thấy ${extractedPosts.length} bài viết hợp lệ qua GraphQL.`);
    } else {
      let debugStr = '';
      if (allResponses.length > 0) {
        debugStr = `Đã nhận ${allResponses.length} chunk JSON nhưng không tìm thấy data post. Gói đầu tiên: ${JSON.stringify(allResponses[0]).substring(0, 150)}`;
      } else {
        debugStr = responseText.substring(0, 300);
      }
      sendMessage(uiTabId, 'status_update', `⚠️ Không tìm thấy bài viết. Trả về: ${debugStr}`);
    }

    sendMessage(uiTabId, 'page_posts_complete', null);
  } catch (error) {
    console.error('Error scanning page posts:', error);
    sendMessage(uiTabId, 'error', `Lỗi quét bài viết (API): ${error.message}`);
  } finally {
    if (isTempTab && fbTabId) {
      try { await chrome.tabs.remove(fbTabId); } catch(e) {}
    }
  }
}


// ========================================
// Page Posts Feature - Share Post to Group (API Method)
// ========================================
async function sharePostToGroup(uiTabId, { groupId, groupUrl, postUrl }) {
  let activeFbTabId = null;
  let isTempTab = false;
  try {
    sendMessage(uiTabId, 'status_update', `Đang chia sẻ bài viết lên nhóm ${groupId} qua API...`);

    // Validate URL
    if (!postUrl || !postUrl.includes('facebook.com')) {
      sendMessage(uiTabId, 'SHARE_ERROR', { groupId, message: 'URL bài viết không hợp lệ' });
      return;
    }

    // Refresh tokens from the active FB tab
    sendMessage(uiTabId, 'status_update', 'Đang lấy tokens mới nhất...');
    const connection = await getTokensResilient(uiTabId);
    let freshTokens = null;
    
    if (connection) {
      freshTokens = connection.tokens;
      activeFbTabId = connection.tabId;
      isTempTab = connection.isTemp;
      await chrome.storage.local.set({ fbTabId: activeFbTabId });
    }

    let finalTokens = null;
    const storedTokens = await chrome.storage.local.get('fbTokens');
    
    if (freshTokens && freshTokens.dtsg) {
      finalTokens = { ...(storedTokens.fbTokens || {}), ...freshTokens };
      await chrome.storage.local.set({ fbTokens: finalTokens });
    } else if (storedTokens.fbTokens && storedTokens.fbTokens.dtsg) {
      finalTokens = storedTokens.fbTokens;
      sendMessage(uiTabId, 'status_update', 'Sử dụng tokens được lưu trữ (cached)...');
    } else {
      throw new Error('Không thể lấy tokens. Vui lòng kiểm tra lại trạng thái đăng nhập Facebook.');
    }

    sendMessage(uiTabId, 'status_update', '⚡ Phương thức: GraphQL API - Đang gửi request chia sẻ...');
    await shareViaAPI(uiTabId, activeFbTabId, groupId, postUrl, finalTokens);

  } catch (error) {
    console.error('[SharePost] Error:', error);
    sendMessage(uiTabId, 'SHARE_ERROR', { groupId, message: error.message });
  } finally {
    if (isTempTab && activeFbTabId) {
      try { await chrome.tabs.remove(activeFbTabId); } catch(e) {}
    }
  }
}

async function shareViaAPI(uiTabId, fbTabId, groupId, postUrl, tokens) {
  try {
    const uuid = () => 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
      const r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });

    const session_id = uuid();

    // DYNAMIC DOC ID RETRIEVAL
    let mutationDocId = null;
    try {
      sendMessage(uiTabId, 'STATUS_UPDATE', { message: '🔑 Đang lấy mã xác thực (doc_id) từ Facebook...' });
      const dynamicId = await getCreatePostDocId(fbTabId);
      if (dynamicId) {
        mutationDocId = dynamicId;
        sendMessage(uiTabId, 'STATUS_UPDATE', { message: `✅ Đã lấy doc_id: ${dynamicId.slice(0, 8)}...` });
      }
    } catch (e) {
      console.warn('[ShareAPI] Failed to get dynamic ID:', e);
    }

    if (!mutationDocId) {
      mutationDocId = '24136403722723544';
      sendMessage(uiTabId, 'STATUS_UPDATE', { message: '⚠️ Dùng tân doc_id (ComposerStoryCreateMutation) từ FBTool...' });
    }

    // Extract postId from URL
    let postId = null;
    const urlMatch = /(?:fbid=|\/posts\/|\/videos\/|\/photos\/)([0-9a-zA-Z_]+)/.exec(postUrl);
    if (urlMatch) {
      postId = urlMatch[1];
    } else {
      const numbers = postUrl.match(/\d+/g);
      if (numbers) postId = numbers[numbers.length - 1];
    }

    if (!postId) {
      throw new Error(`Không tìm thấy ID bài viết số trong link: ${postUrl}`);
    }

    // Prepare attachment for "Share" action with Stringified JSON
    const attachments = [{
      "link": {
        "share_scrape_data": JSON.stringify({
          "share_type": 22,
          "share_params": [parseInt(postId)]
        })
      }
    }];

    const variables = {
      "input": {
        "composer_entry_point": "inline_composer",
        "composer_source_surface": "group",
        "composer_type": "group",
        "logging": {
          "composer_session_id": session_id
        },
        "source": "WWW",
        "is_tracking_encrypted": true,
        "tracking": [null],
        "message": {
          "ranges": [],
          "text": "" // Shared post text
        },
        "with_tags_ids": null,
        "inline_activities": [],
        "text_format_preset_id": "0",
        "group_flair": { "flair_id": null },
        "attachments": attachments,
        "event_share_metadata": { "surface": "newsfeed" },
        "audience": {
          "to_id": groupId
        },
        "actor_id": tokens.userId,
        "client_mutation_id": Math.floor(Math.random() * 100000).toString()
      },
      "feedLocation": "GROUP",
      "feedbackSource": 0,
      "focusCommentID": null,
      "gridMediaWidth": null,
      "groupID": null,
      "scale": 2,
      "privacySelectorRenderLocation": "COMET_STREAM",
      "checkPhotosToReelsUpsellEligibility": false,
      "referringStoryRenderLocation": null,
      "renderLocation": "group",
      "useDefaultActor": false,
      "inviteShortLinkKey": null,
      "isFeed": false,
      "isFundraiser": false,
      "isFunFactPost": false,
      "isGroup": true,
      "isEvent": false,
      "isTimeline": false,
      "isSocialLearning": false,
      "isPageNewsFeed": false,
      "isProfileReviews": false,
      "isWorkSharedDraft": false,
      "hashtag": null,
      "canUserManageOffers": false
    };

    const responseText = await fetchGraphQLInTab(fbTabId, tokens, variables, mutationDocId, 'ComposerStoryCreateMutation');

    if (!responseText) throw new Error('Không có phản hồi từ Server Facebook');

    if (isCheckpoint(responseText)) {
      throw new Error('checkpoint detected - Facebook yêu cầu xác minh');
    }

    const response = parseResponse(responseText);

    const postCreateResult = response && response.data && (response.data.story_create || response.data.group_post_create || response.data.group_create_post);
    if (postCreateResult) {
      const post = postCreateResult.post || postCreateResult.story || {};
      const shareId = post.id || post.post_id || post.story_fbid || postId;
      const shareLink = `https://www.facebook.com/groups/${groupId}/posts/${shareId}/`;

      if (mutationDocId) {
        await saveDocIdToCache(mutationDocId);
      }

      sendMessage(uiTabId, 'STATUS_UPDATE', { message: `✅ Chia sẻ thành công! ID: ${postId}` });
      sendMessage(uiTabId, 'SHARE_SUCCESS', { groupId, postUrl: shareLink });
      return;
    }

    if (response && response.errors) {
      await clearDocIdCache();
      throw new Error(response.errors[0]?.message || 'Lỗi GraphQL');
    }

    if (response && response.data === null) {
      await clearDocIdCache();
      throw new Error('Facebook từ chối yêu cầu (Data is null) - doc_id có thể hết hạn');
    }

    let errorMsg = 'Lỗi không xác định (API Response Unknown)';
    if (!response) {
      errorMsg = `Không thể phân tích phản hồi từ Facebook: ${responseText ? responseText.substring(0, 100) : 'Rỗng'}`;
    } else if (response.errorSummary) {
      errorMsg = `${response.errorSummary} - ${response.errorDescription || ''}`;
    } else if (response.error?.message) {
      errorMsg = response.error.message;
    } else if (response.error && typeof response.error === 'object') {
      errorMsg = `Lỗi hệ thống FB: ${response.error.errorSummary || response.error.description || JSON.stringify(response.error)}`;
    } else if (response.data?.error) {
      errorMsg = response.data.error.message || JSON.stringify(response.data.error);
    } else if (typeof response === 'string') {
      errorMsg = 'Response dạng text: ' + response.substring(0, 100);
    }

    await clearDocIdCache();
    throw new Error(errorMsg);

  } catch (e) {
    throw e;
  }
}


async function getOrCreateFbTab() {
  const fbTabs = await chrome.tabs.query({ url: '*://*.facebook.com/*' });
  let tabId;
  if (fbTabs.length > 0) {
    tabId = fbTabs[0].id;
  } else {
    const newTab = await chrome.tabs.create({ url: 'https://www.facebook.com/', active: false });
    await waitForPageLoad(newTab.id, 5000);
    tabId = newTab.id;
  }

  // Setup doc_id interception on the Facebook tab
  try {
    await setupDocIdInterception(tabId);
  } catch (e) {
    console.warn('[getOrCreateFbTab] Failed to setup interception:', e);
  }

  return tabId;
}

async function waitForPageLoad(tabId, timeout = 5000) {
  return new Promise((resolve) => {
    const startTime = Date.now();
    const check = () => {
      chrome.tabs.get(tabId, (tab) => {
        if (tab.status === 'complete' || Date.now() - startTime > timeout) {
          resolve();
        } else {
          setTimeout(check, 200);
        }
      });
    };
    check();
  });
}

async function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ========================================
// User Pages Extraction (mbasic approach - NO tab redirects)
// ========================================
async function fetchUserPages(uiTabId) {
  let fbTabId = null;
  let isTempTab = false;
  try {
    sendMessage(uiTabId, 'status_update', 'Đang kết nối để lấy danh sách Trang (không qua DOM)...');

    const connection = await getTokensResilient(uiTabId);
    if (!connection) {
      throw new Error('Không tìm thấy tab Facebook. Vui lòng mở Facebook hoặc đăng nhập.');
    }
    fbTabId = connection.tabId;
    isTempTab = connection.isTemp;

    // Fetch www.facebook.com/pages pages section in background
    let html = '';
    try {
      const response = await fetch('https://www.facebook.com/pages/?category=your_pages', {
        headers: {
          'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
          'accept-language': 'en-US,en;q=0.9,vi;q=0.8',
          'cache-control': 'max-age=0',
          'sec-ch-ua': '"Google Chrome";v="119", "Chromium";v="119", "Not?A_Brand";v="24"',
          'sec-ch-ua-mobile': '?0',
          'sec-ch-ua-platform': '"Windows"',
          'sec-fetch-dest': 'document',
          'sec-fetch-mode': 'navigate',
          'sec-fetch-site': 'same-origin',
          'sec-fetch-user': '?1',
          'upgrade-insecure-requests': '1'
        },
        credentials: 'include'
      });
      if (response.ok) {
        html = await response.text();
      }
    } catch (e) {
      console.error('Background fetch WWW pages failed:', e);
    }

    if (!html) {
      sendMessage(uiTabId, 'status_update', '⚠️ Không thể tải danh sách Trang từ www (Lỗi mạng hoặc bị chặn).');
      return;
    }

    let pagesData = [];
    if (fbTabId) {
      const pagesResult = await chrome.scripting.executeScript({
        target: { tabId: fbTabId },
        world: 'MAIN',
        args: [html],
        func: (htmlString) => {
          try {
            const pages = [];
            const seenIds = new Set();
            const pageRegex = /{"__typename":"Page","id":"(\d+)","name":"([^"]+)"(?:,"profile_picture":{"uri":"([^"]+)")?/g;
            let match;
            while ((match = pageRegex.exec(htmlString)) !== null) {
              const id = match[1];
              const name = match[2];
              const cleanName = name.replace(/\\u[\dA-F]{4}/gi, (m) => String.fromCharCode(parseInt(m.replace(/\\u/g, ''), 16)));
              let image = match[3] ? match[3].replace(/\\/g, '') : null;
              if (!seenIds.has(id) && cleanName && cleanName.length > 1) {
                seenIds.add(id);
                pages.push({
                  id: id,
                  name: cleanName,
                  url: `https://www.facebook.com/${id}`,
                  image: image
                });
              }
            }
            if (pages.length === 0) {
              const fallbackRegex = /"pageID":"(\d+)","name":"([^"]+)"/g;
              while ((match = fallbackRegex.exec(htmlString)) !== null) {
                const id = match[1];
                const cleanName = match[2].replace(/\\u[\dA-F]{4}/gi, (m) => String.fromCharCode(parseInt(m.replace(/\\u/g, ''), 16)));
                if (!seenIds.has(id)) {
                  seenIds.add(id);
                  pages.push({
                    id: id,
                    name: cleanName,
                    url: `https://www.facebook.com/${id}`,
                    image: null
                  });
                }
              }
            }
            return pages;
          } catch (e) {
            console.error('[fetchUserPages WWW Regex Error]', e);
            return [];
          }
        }
      });
      pagesData = pagesResult[0]?.result || [];
    } else {
      // Run the parsing directly in the background script!
      try {
        const pages = [];
        const seenIds = new Set();
        const pageRegex = /{"__typename":"Page","id":"(\d+)","name":"([^"]+)"(?:,"profile_picture":{"uri":"([^"]+)")?/g;
        let match;
        while ((match = pageRegex.exec(html)) !== null) {
          const id = match[1];
          const name = match[2];
          const cleanName = name.replace(/\\u[\dA-F]{4}/gi, (m) => String.fromCharCode(parseInt(m.replace(/\\u/g, ''), 16)));
          let image = match[3] ? match[3].replace(/\\/g, '') : null;
          if (!seenIds.has(id) && cleanName && cleanName.length > 1) {
            seenIds.add(id);
            pages.push({
              id: id,
              name: cleanName,
              url: `https://www.facebook.com/${id}`,
              image: image
            });
          }
        }
        if (pages.length === 0) {
          const fallbackRegex = /"pageID":"(\d+)","name":"([^"]+)"/g;
          while ((match = fallbackRegex.exec(html)) !== null) {
            const id = match[1];
            const cleanName = match[2].replace(/\\u[\dA-F]{4}/gi, (m) => String.fromCharCode(parseInt(m.replace(/\\u/g, ''), 16)));
            if (!seenIds.has(id)) {
              seenIds.add(id);
              pages.push({
                id: id,
                name: cleanName,
                url: `https://www.facebook.com/${id}`,
                image: null
              });
            }
          }
        }
        pagesData = pages;
      } catch (e) {
        console.error('[fetchUserPages Background Regex Error]', e);
      }
    }
    sendMessage(uiTabId, 'fb_pages_data', pagesData);

  } catch (error) {
    console.error('Error fetching user pages:', error);
    sendMessage(uiTabId, 'fb_pages_data', []);
  } finally {
    if (isTempTab && fbTabId) {
      try { await chrome.tabs.remove(fbTabId); } catch(e) {}
    }
  }
}

async function getCurrentPageInfo(uiTabId) {
  try {
    sendMessage(uiTabId, 'status_update', 'Đang lấy thông tin Page hiện tại...');

    // Find active FB tab
    const tabs = await chrome.tabs.query({ url: '*://*.facebook.com/*' });
    console.log('Found FB tabs:', tabs.map(t => t.url));

    // Filter out generic pages
    const validTabs = tabs.filter(t => {
      const url = t.url;
      // Check for specific "white-listed" patterns if possible, or black-list everything else
      const isHome = url === 'https://www.facebook.com/' ||
        url === 'https://facebook.com/' ||
        url.includes('facebook.com/home.php');

      const isSystem = url.includes('/watch') ||
        url.includes('/marketplace') ||
        url.includes('/groups/') ||
        url.includes('/gaming') ||
        url.includes('/messages') ||
        url.includes('/bookmarks');

      return !isHome && !isSystem;
    });

    console.log('Valid Page tabs:', validTabs.map(t => t.url));

    let targetTab = null;

    // Prioritize active/highlighted valid tab strictly
    targetTab = validTabs.find(t => t.active && t.lastAccessed);
    if (!targetTab) targetTab = validTabs.sort((a, b) => b.lastAccessed - a.lastAccessed)[0];

    // If we still can't find a "valid" tab, but there are FB tabs, maybe our filter is too strict?
    // Let's try the most active FB tab as a last resort, but warn the script might reject it
    if (!targetTab && tabs.length > 0) {
      console.log('No valid Page tab found, falling back to most active FB tab');
      targetTab = tabs.sort((a, b) => b.lastAccessed - a.lastAccessed)[0];
    }

    if (!targetTab) {
      throw new Error('Không tìm thấy tab Facebook nào đang mở.');
    }

    console.log('Targeting Tab:', targetTab.url);

    const pageInfo = await chrome.scripting.executeScript({
      target: { tabId: targetTab.id },
      func: () => {
        try {
          let url = window.location.href;
          const pathname = window.location.pathname;
          let id = null;
          let image = null;
          let name = null;

          // 1. Try to get Page Name and ID from CurrentUserInitialData (extremely robust for page switcher mode)
          try {
            if (window.CurrentUserInitialData) {
              if (window.CurrentUserInitialData.NAME && window.CurrentUserInitialData.NAME !== 'Facebook') {
                name = window.CurrentUserInitialData.NAME;
              }
              if (window.CurrentUserInitialData.USER_ID) {
                id = window.CurrentUserInitialData.USER_ID;
              }
            }
          } catch (e) {}

          // 2. Try to extract name from Page Title
          if (!name) {
            let title = document.title;
            title = title.replace(/^\(\d+[\+\d]*\)\s*/, '');
            const cleanTitle = title.replace(/ \| Facebook$/, '').trim();
            if (cleanTitle && cleanTitle !== 'Facebook') {
              name = cleanTitle;
            }
          }

          // 3. Fallback: try to find h1 element on timeline page
          if (!name || name === 'Facebook') {
            const h1 = document.querySelector('h1');
            if (h1 && h1.innerText && h1.innerText.trim() !== 'Facebook') {
              name = h1.innerText.trim();
            }
          }

          // 4. Clean up invalid/localized generic user name strings like "bạn"
          if (name && (name.toLowerCase() === 'bạn' || name.toLowerCase() === 'ảnh đại diện của bạn' || name.toLowerCase() === 'trang cá nhân của bạn')) {
            name = null;
          }

          // 5. Try to find the Numeric ID from Deep Link Meta Tags (super robust for custom usernames!)
          if (!id) {
            try {
              const metaTag = document.querySelector('meta[property="al:android:url"], meta[property="al:ios:url"]');
              if (metaTag) {
                const content = metaTag.getAttribute('content');
                const m = content.match(/id=(\d+)/) || content.match(/profile\/(\d+)/);
                if (m) id = m[1];
              }
            } catch (e) {}
          }

          // 6. Try to extract ID from URL regexes
          if (!id) {
            const matchId = url.match(/\/(\d+)\/?/) || url.match(/id=(\d+)/);
            if (matchId) id = matchId[1];
            else {
              const parts = new URL(url).pathname.split('/').filter(p => p);
              const reserved = ['profile.php', 'watch', 'groups', 'marketplace', 'gaming', 'messages', 'bookmarks', 'events', 'saved', 'home.php'];
              if (parts.length > 0 && !reserved.includes(parts[0])) {
                id = parts[0];
              }
            }
          }

          // 7. If on homepage/generic page, try Strategy A1 (Main Account controls button)
          const isGeneric = pathname === '/' || pathname === '/home.php' || !name || name === 'Facebook';
          if (isGeneric) {
            console.log('Generic/Home detected, searching for Acting As profile...');
            let profileFound = null;

            // Strategy A1: Account button
            const accountBtnMain = document.querySelector('div[role="navigation"] div[role="button"][aria-label*="Tài khoản"], div[role="navigation"] div[role="button"][aria-label*="Account"]');
            if (accountBtnMain) {
              const label = accountBtnMain.getAttribute('aria-label');
              if (label) {
                let clean = label.replace('Điều khiển và cài đặt tài khoản cho ', '')
                  .replace('Account controls and settings for ', '')
                  .replace('Tài khoản của ', '')
                  .replace('Account of ', '')
                  .trim();
                if (clean && clean.length > 2 && clean.toLowerCase() !== 'bạn') {
                  const img = accountBtnMain.querySelector('img, svg image');
                  profileFound = { href: window.location.href, text: clean, img: img, isFallback: true };
                }
              }
            }

            // Strategy B2: Image Alt / Menu Button alt
            if (!profileFound) {
              const img = document.querySelector('img[alt*="Ảnh đại diện của "], img[alt*="Profile picture of "]');
              if (img) {
                const alt = img.getAttribute('alt');
                const cleanName = alt.replace('Ảnh đại diện của ', '').replace('Profile picture of ', '').trim();
                if (cleanName && cleanName.toLowerCase() !== 'bạn') {
                  profileFound = { href: window.location.href, text: cleanName, img: img, isFallback: true };
                }
              }
            }

            if (profileFound) {
              name = profileFound.text;
              const pImg = profileFound.img;
              if (pImg) {
                image = pImg.src || pImg.getAttribute('xlink:href');
              }
            }
          }

          // 8. Robust Avatar Extraction
          const isProfileImage = (u) => {
            return u && u.includes('fbcdn.net') && !u.includes('static.') && !u.includes('/rsrc.php') && !u.includes('emoji');
          };

          if (!image) {
            // Check SVG images
            const svgImages = document.querySelectorAll('image');
            for (const img of svgImages) {
              const href = img.getAttribute('xlink:href') || img.getAttribute('href');
              if (isProfileImage(href)) {
                image = href;
                break;
              }
            }
          }

          if (!image) {
            // Check account buttons
            const accountAreas = document.querySelectorAll('[aria-label*="Account"], [aria-label*="Tài khoản"], nav, header, [role="banner"]');
            for (const area of accountAreas) {
              const imgs = area.querySelectorAll('img');
              for (const img of imgs) {
                if (isProfileImage(img.src) && img.width >= 28 && img.width <= 120) {
                  image = img.src;
                  break;
                }
              }
              if (image) break;
            }
          }

          if (!image) {
            // Scan all square page images
            const allImgs = document.querySelectorAll('img');
            for (const img of allImgs) {
              if (isProfileImage(img.src)) {
                const w = img.width || img.naturalWidth;
                if (w >= 28 && w <= 120) {
                  image = img.src;
                  break;
                }
              }
            }
          }

          if (!id && name) id = 'page_' + name.replace(/\s+/g, '_').toLowerCase();
          if (!id) id = 'page_' + Date.now();

          if ((!name || name === 'Facebook') && !image) return null;

          return { id, name: name || 'Facebook Page', url, image };
        } catch (e) {
          console.error('Script Error:', e);
          return null;
        }
      }
    });

    if (pageInfo && pageInfo[0].result) {
      sendMessage(uiTabId, 'current_page_info', pageInfo[0].result);
      sendMessage(uiTabId, 'status_update', 'Đã lấy thông tin Page: ' + pageInfo[0].result.name);
    } else {
      throw new Error('Không xác định được Page. Quy trình: Switch Profile -> Vào mục Page (hoặc Home) -> Bấm Tool.');
    }

  } catch (error) {
    console.error('getCurrentPageInfo Error:', error);
    sendMessage(uiTabId, 'error', error.message);
  }
}

// ========================================
// Doc ID Cache System (24h expiration)
// ========================================
const DOC_ID_CACHE_EXPIRY_MS = 24 * 60 * 60 * 1000; // 24 hours

async function getCachedDocId() {
  try {
    const data = await chrome.storage.local.get(['cachedDocId', 'cachedDocIdTimestamp']);
    if (data.cachedDocId && data.cachedDocIdTimestamp) {
      const age = Date.now() - data.cachedDocIdTimestamp;
      if (age < DOC_ID_CACHE_EXPIRY_MS) {
        console.log('[DocID Cache] Using cached doc_id:', data.cachedDocId, 'age:', Math.round(age / 60000), 'min');
        return data.cachedDocId;
      } else {
        console.log('[DocID Cache] Cache expired:', Math.round(age / 3600000), 'hours old');
      }
    }
  } catch (e) {
    console.warn('[DocID Cache] Error reading cache:', e);
  }
  return null;
}

async function saveDocIdToCache(docId) {
  try {
    await chrome.storage.local.set({
      cachedDocId: docId,
      cachedDocIdTimestamp: Date.now()
    });
    console.log('[DocID Cache] Saved doc_id to cache:', docId);
  } catch (e) {
    console.warn('[DocID Cache] Error saving cache:', e);
  }
}

// ========================================
// Dynamic Group Scan Doc ID Retrieval
// ========================================
async function getGroupScanDocIds(tabId) {
  const result = await chrome.scripting.executeScript({
    target: { tabId: tabId },
    world: 'MAIN',
    func: () => {
      try {
        let rootDocId = null;
        let paginationDocId = null;

        // Strategy 1: Check captured doc_ids from fetch interception
        if (window.__FB_CAPTURED_DOC_IDS && window.__FB_CAPTURED_DOC_IDS.length > 0) {
          for (const d of window.__FB_CAPTURED_DOC_IDS) {
            if (d.name && d.name.includes('GroupsCometJoinsRootQuery')) {
              rootDocId = d.id;
              console.log('[GroupDocID] Found root doc_id from capture:', rootDocId);
            }
            if (d.name && d.name.includes('GroupsCometAllJoinedGroupsSectionPaginationQuery')) {
              paginationDocId = d.id;
              console.log('[GroupDocID] Found pagination doc_id from capture:', paginationDocId);
            }
          }
        }

        // Strategy 2: Try window.require for Facebook modules
        if (!rootDocId && window.require) {
          const moduleNames = [
            'GroupsCometJoinsRootQuery.graphql',
            'GroupsCometJoinedGroupsQuery.graphql',
            'GroupsCometAllJoinedGroupsQuery.graphql'
          ];
          for (const m of moduleNames) {
            try {
              const mod = window.require(m);
              if (mod && mod.params && mod.params.id) {
                rootDocId = mod.params.id;
                console.log('[GroupDocID] Found root via require:', m, rootDocId);
                break;
              }
            } catch (e) { }
          }
        }
        if (!paginationDocId && window.require) {
          const paginationModules = [
            'GroupsCometAllJoinedGroupsSectionPaginationQuery.graphql',
            'GroupsCometJoinedGroupsPaginationQuery.graphql'
          ];
          for (const m of paginationModules) {
            try {
              const mod = window.require(m);
              if (mod && mod.params && mod.params.id) {
                paginationDocId = mod.params.id;
                console.log('[GroupDocID] Found pagination via require:', m, paginationDocId);
                break;
              }
            } catch (e) { }
          }
        }

        // Strategy 3: Parse from page HTML
        const html = document.documentElement.innerHTML;

        if (!rootDocId) {
          const rootPatterns = [
            /\"doc_id\":\"(\d+)\"[^}]*\"GroupsCometJoinsRootQuery\"/,
            /\"GroupsCometJoinsRootQuery\"[^}]*\"doc_id\":\"(\d+)\"/,
            /GroupsCometJoinsRoot[^}]*\"doc_id\":\"(\d+)\"/,
            /\"doc_id\":\"(\d+)\"[^}]*GroupsCometJoinsRoot/
          ];
          for (const pattern of rootPatterns) {
            const match = html.match(pattern);
            if (match && match[1]) {
              rootDocId = match[1];
              console.log('[GroupDocID] Found root via HTML pattern:', rootDocId);
              break;
            }
          }
        }

        if (!paginationDocId) {
          const paginationPatterns = [
            /\"doc_id\":\"(\d+)\"[^}]*\"GroupsCometAllJoinedGroupsSectionPaginationQuery\"/,
            /\"GroupsCometAllJoinedGroupsSectionPaginationQuery\"[^}]*\"doc_id\":\"(\d+)\"/,
            /GroupsCometAllJoinedGroupsSection[^}]*\"doc_id\":\"(\d+)\"/,
            /\"doc_id\":\"(\d+)\"[^}]*GroupsCometAllJoinedGroupsSection/
          ];
          for (const pattern of paginationPatterns) {
            const match = html.match(pattern);
            if (match && match[1]) {
              paginationDocId = match[1];
              console.log('[GroupDocID] Found pagination via HTML pattern:', paginationDocId);
              break;
            }
          }
        }

        // Strategy 4: Scan script tags
        if (!rootDocId || !paginationDocId) {
          const scripts = document.querySelectorAll('script');
          for (const script of scripts) {
            const text = script.textContent || '';
            if (text.includes('GroupsCometJoins') || text.includes('AllJoinedGroups')) {
              const allDocIds = [...text.matchAll(/\"doc_id\":\"(\d+)\"/g)];
              const allNames = [...text.matchAll(/\"name\":\"([^\"]+)\"/g)];
              
              // Try to match doc_id with query names
              if (!rootDocId) {
                const rootIdx = allNames.findIndex(m => m[1].includes('GroupsCometJoinsRoot'));
                if (rootIdx >= 0 && allDocIds[rootIdx]) {
                  rootDocId = allDocIds[rootIdx][1];
                  console.log('[GroupDocID] Found root via script scan:', rootDocId);
                }
              }
              if (!paginationDocId) {
                const pagIdx = allNames.findIndex(m => m[1].includes('AllJoinedGroupsSection'));
                if (pagIdx >= 0 && allDocIds[pagIdx]) {
                  paginationDocId = allDocIds[pagIdx][1];
                  console.log('[GroupDocID] Found pagination via script scan:', paginationDocId);
                }
              }

            }
          }
        }

        console.log('[GroupDocID] Result - root:', rootDocId, 'pagination:', paginationDocId);
        return { rootDocId, paginationDocId };
      } catch (e) {
        console.error('[GroupDocID] Error:', e);
        return null;
      }
    }
  });
  return result[0]?.result;
}

async function clearDocIdCache() {
  try {
    await chrome.storage.local.remove(['cachedDocId', 'cachedDocIdTimestamp']);
    console.log('[DocID Cache] Cache cleared');
  } catch (e) {
    console.warn('[DocID Cache] Error clearing cache:', e);
  }
}

// ========================================
// Dynamic Doc ID Helper
// ========================================
async function getCreatePostDocId(tabId) {
  // First, check cached doc_id
  const cachedId = await getCachedDocId();
  if (cachedId) {
    console.log('[DocID] Using cached doc_id:', cachedId);
    return cachedId;
  }

  const result = await chrome.scripting.executeScript({
    target: { tabId: tabId },
    world: 'MAIN',
    func: () => {
      return new Promise((resolve) => {
        try {
          let foundId = null;

          // Strategy 1: Check if we have previously captured doc_id
          if (window.__FB_CAPTURED_DOC_IDS && window.__FB_CAPTURED_DOC_IDS.length > 0) {
            // Find the most relevant doc_id for group posting
            const groupDocId = window.__FB_CAPTURED_DOC_IDS.find(d =>
              d.name && (d.name.includes('Group') || d.name.includes('Compose'))
            );
            if (groupDocId) {
              console.log('[DocID] Using captured doc_id:', groupDocId);
              resolve(groupDocId.id);
              return;
            }
            // Use last captured if no group-specific found
            resolve(window.__FB_CAPTURED_DOC_IDS[window.__FB_CAPTURED_DOC_IDS.length - 1].id);
            return;
          }

          // Strategy 2: Try window.require for Facebook modules
          const modules = [
            "GroupCometComposeBoxPostMutation.graphql",
            "CometGroupPostMutation.graphql",
            "GroupFeedStoryCreateMutation.graphql",
            "CometNewsFeedPostMutation.graphql",
            "GroupPostCreateMutation.graphql"
          ];

          if (window.require) {
            for (const m of modules) {
              try {
                const mod = window.require(m);
                if (mod && mod.params && mod.params.id) {
                  foundId = mod.params.id;
                  console.log('[DocID] Found via require:', m, foundId);
                  break;
                }
              } catch (e) { }
            }
          }

          if (foundId) {
            resolve(foundId);
            return;
          }

          // Strategy 3: Parse doc_id from page HTML/scripts - IMPROVED PATTERNS
          const html = document.documentElement.innerHTML;

          const patterns = [
            // Group post mutations
            /"doc_id":"(\d+)"[^}]*"GroupFeedStoryCreateMutation"/,
            /"GroupFeedStoryCreateMutation"[^}]*"doc_id":"(\d+)"/,
            /GroupCometComposeBoxPostMutation[^}]*"doc_id":"(\d+)"/,
            /"doc_id":"(\d+)"[^}]*GroupCometComposeBox/,
            /"doc_id":"(\d+)"[^}]*"GroupPostCreateMutation"/,
            /"GroupPostCreateMutation"[^}]*"doc_id":"(\d+)"/,
            // Comet compose
            /CometComposer[^}]*"doc_id":"(\d+)"/,
            /"doc_id":"(\d+)"[^}]*CometComposer/
          ];

          for (const pattern of patterns) {
            const match = html.match(pattern);
            if (match && match[1]) {
              foundId = match[1];
              console.log('[DocID] Found via HTML pattern:', foundId);
              break;
            }
          }

          if (foundId) {
            resolve(foundId);
            return;
          }

          // Strategy 4: Scan all script tags for doc_id
          const scripts = document.querySelectorAll('script');
          for (const script of scripts) {
            const text = script.textContent || '';
            if (text.includes('GroupFeedStoryCreate') ||
              text.includes('ComposeBox') ||
              text.includes('GroupPost')) {
              const docMatch = text.match(/"doc_id":"(\d+)"/);
              if (docMatch) {
                foundId = docMatch[1];
                console.log('[DocID] Found via script scan:', foundId);
                break;
              }
            }
          }

          if (foundId) {
            resolve(foundId);
            return;
          }

          resolve(foundId);
        } catch (e) {
          console.error('[DocID] Error:', e);
          resolve(null);
        }
      });
    }
  });
  return result[0]?.result;
}

// Setup fetch interception to capture doc_id from Facebook's actual API calls
async function setupDocIdInterception(tabId) {
  await chrome.scripting.executeScript({
    target: { tabId: tabId },
    world: 'MAIN',
    func: () => {
      if (window.__FB_FETCH_INTERCEPTED) return;
      window.__FB_FETCH_INTERCEPTED = true;
      window.__FB_CAPTURED_DOC_IDS = [];

      const originalFetch = window.fetch;
      window.fetch = async function (...args) {
        const response = await originalFetch.apply(this, args);

        try {
          const url = args[0]?.url || args[0];
          if (url && url.includes('/api/graphql')) {
            // Try to capture doc_id from request body
            const body = args[1]?.body;
            if (body) {
              let bodyStr = '';
              if (typeof body === 'string') {
                bodyStr = body;
              } else if (body instanceof URLSearchParams) {
                bodyStr = body.toString();
              }

              const docIdMatch = bodyStr.match(/doc_id=(\d+)/);
              const nameMatch = bodyStr.match(/fb_api_req_friendly_name=([^&]+)/);

              if (docIdMatch) {
                const docId = docIdMatch[1];
                const name = nameMatch ? decodeURIComponent(nameMatch[1]) : 'unknown';

                // Store unique doc_ids
                if (!window.__FB_CAPTURED_DOC_IDS.find(d => d.id === docId)) {
                  window.__FB_CAPTURED_DOC_IDS.push({ id: docId, name: name });
                  console.log('[DocID Interceptor] Captured:', name, docId);

                  // Keep only last 20
                  if (window.__FB_CAPTURED_DOC_IDS.length > 20) {
                    window.__FB_CAPTURED_DOC_IDS.shift();
                  }
                }
              }
            }
          }
        } catch (e) {
          // Ignore interception errors
        }

        return response;
      };

      console.log('[DocID Interceptor] Setup complete');
    }
  });
}

// ========================================
// DOM Automation Posting (Simulate Clicks - No doc_id)
// ========================================
async function postViaDOMAutomation(uiTabId, fbTabId, groupId, content, images) {
  try {
    const groupUrl = `https://www.facebook.com/groups/${groupId}`;
    sendMessage(uiTabId, 'STATUS_UPDATE', { message: '⚡ Mở trang nhóm...' });
    
    await chrome.tabs.update(fbTabId, { url: groupUrl, active: true });
    
    try {
      const tab = await chrome.tabs.get(fbTabId);
      await chrome.windows.update(tab.windowId, { focused: true });
    } catch(e) {}

    await new Promise(r => setTimeout(r, 4000));
    
    sendMessage(uiTabId, 'STATUS_UPDATE', { message: '⚡ Đang thực thi Auto-DOM...' });
    
    const results = await chrome.scripting.executeScript({
      target: { tabId: fbTabId },
      world: 'MAIN',
      args: [content, images || [], groupId],
      func: async (postContent, postImages, postGroupId) => {
        const sleep = ms => new Promise(r => setTimeout(r, ms));
        
        // 1. Find Composer
        const composerSelectors = [
          'div[role="button"][tabindex="0"][class*="x1i10hfl"] span[data-lexical-text="true"]',
          'div[aria-label*="Write something"]',
          'div[aria-label*="Viết gì đó"]',
          'div[aria-label*="Bạn viết gì đi"]',
          'div[data-testid="composer-box"]'
        ];
        
        let composerFound = false;
        for (let sel of composerSelectors) {
           let el = document.querySelector(sel);
           if (!el) {
               const allSpans = Array.from(document.querySelectorAll('span'));
               el = allSpans.find(s => s.textContent && (
                   s.textContent.includes('Viết gì đó') || 
                   s.textContent.includes('Bạn viết gì đi') || 
                   s.textContent.includes('Write something')
               ));
           }
           if (el) {
              el.scrollIntoView({block: 'center'});
              await sleep(1000);
              el.click();
              composerFound = true;
              break;
           }
        }
        
        if (!composerFound) return { success: false, error: 'Không tìm thấy khung soạn thảo bài viết.' };
        await sleep(2000);

        // 2. Paste content
        const dialogSelectors = [
          'div[role="dialog"] div[data-lexical-editor="true"]',
          'div[role="textbox"][contenteditable="true"]'
        ];
        
        let textBox = null;
        for (let sel of dialogSelectors) {
          textBox = document.querySelector(sel);
          if (textBox) break;
        }

        if (!textBox) return { success: false, error: 'Không tìm thấy ô nhập liệu sau khi mở.' };
        
        textBox.focus();
        
        // Place cursor at the end of the text box
        try {
            const range = document.createRange();
            range.selectNodeContents(textBox);
            range.collapse(false);
            const sel = window.getSelection();
            sel.removeAllRanges();
            sel.addRange(range);
        } catch (e) {
            console.warn('Failed to place cursor:', e);
        }

        // Try document.execCommand first as it is the most reliable method for updating Lexical/React states
        let inserted = false;
        try {
            inserted = document.execCommand('insertText', false, postContent);
        } catch (e) {
            console.error('execCommand insertText failed:', e);
        }

        // Fallback to ClipboardEvent paste if execCommand did not work or textbox is still empty
        if (!inserted || !textBox.textContent.trim()) {
            console.log('execCommand fallback: simulating paste event...');
            const dataTransfer = new DataTransfer();
            dataTransfer.setData('text/plain', postContent);
            const pasteEvent = new ClipboardEvent('paste', {
              clipboardData: dataTransfer,
              bubbles: true,
              cancelable: true
            });
            textBox.dispatchEvent(pasteEvent);
        }
        
        const inputEvent = new Event('input', { bubbles: true });
        textBox.dispatchEvent(inputEvent);
        await sleep(2000);

        // 3. Upload images via hidden file input (the ONLY reliable method for Facebook Lexical editor)
        if (postImages && postImages.length > 0) {
            // Helper to search for file input inside the dialog or page
            const getFileInput = () => {
                let input = document.querySelector('div[role="dialog"] input[type="file"][accept*="image"]');
                if (!input) input = document.querySelector('div[role="dialog"] input[type="file"]');
                if (!input) input = document.querySelector('input[type="file"][accept*="image"]');
                if (!input) input = document.querySelector('input[type="file"]');
                return input;
            };

            let fileInput = getFileInput();

            // If file input not found, click the Photo/Video button to reveal it
            if (!fileInput) {
                const photoButtonSelectors = [
                    'div[role="dialog"] div[aria-label="Photo/video"]',
                    'div[role="dialog"] div[aria-label="Ảnh/video"]',
                    'div[role="dialog"] div[aria-label="Photo/Video"]',
                    'div[role="dialog"] div[aria-label="Ảnh/Video"]',
                    'div[role="dialog"] [aria-label*="photo" i]',
                    'div[role="dialog"] [aria-label*="ảnh" i]'
                ];
                
                let photoBtn = null;
                for (const sel of photoButtonSelectors) {
                    photoBtn = document.querySelector(sel);
                    if (photoBtn) break;
                }
                
                // Fallback: scan all buttons in the dialog for photo/video keywords
                if (!photoBtn) {
                    const dialogBtns = document.querySelectorAll('div[role="dialog"] div[role="button"]');
                    for (const btn of dialogBtns) {
                        const label = (btn.getAttribute('aria-label') || '').toLowerCase();
                        if (label.includes('photo') || label.includes('ảnh') || label.includes('hình')) {
                            photoBtn = btn;
                            break;
                        }
                    }
                }
                
                if (photoBtn) {
                    photoBtn.click();
                    // Poll for the file input to appear in the DOM (up to 3 seconds)
                    for (let p = 0; p < 30; p++) {
                        await sleep(100);
                        fileInput = getFileInput();
                        if (fileInput) break;
                    }
                }
            }
            
            // Step 3b: Prepare File objects from base64 data URLs
            const dt = new DataTransfer();
            let hasFiles = false;
            
            for (let idx = 0; idx < postImages.length; idx++) {
                const url = postImages[idx];
                try {
                    let blob;
                    if (typeof url === 'string' && url.startsWith('data:')) {
                        const parts = url.split(',');
                        const byteString = atob(parts[1]);
                        const mimeString = parts[0].split(':')[1].split(';')[0];
                        const ab = new ArrayBuffer(byteString.length);
                        const ia = new Uint8Array(ab);
                        for (let i = 0; i < byteString.length; i++) {
                            ia[i] = byteString.charCodeAt(i);
                        }
                        blob = new Blob([ab], { type: mimeString });
                    } else {
                        const res = await fetch(url);
                        blob = await res.blob();
                    }
                    const filename = 'image_' + Date.now() + '_' + idx + '.jpg';
                    const file = new File([blob], filename, { type: blob.type || 'image/jpeg' });
                    dt.items.add(file);
                    hasFiles = true;
                } catch(e) {
                    console.error('Failed to prepare file for DOM upload:', e);
                }
            }
            
            if (hasFiles && fileInput) {
                try {
                    // Try direct assignment first
                    fileInput.files = dt.files;
                } catch (e) {
                    console.warn('Direct files assignment failed, using defineProperty:', e);
                }

                // Always define property as double-insurance for browser security policies
                try {
                    Object.defineProperty(fileInput, 'files', {
                        value: dt.files,
                        writable: true,
                        configurable: true
                    });
                } catch (e) {
                    console.error('defineProperty files failed:', e);
                }
                
                // Dispatch change and input events to trigger React/Relay handlers
                const changeEvent = new Event('change', { bubbles: true, cancelable: true });
                fileInput.dispatchEvent(changeEvent);
                
                const inputEvt = new Event('input', { bubbles: true, cancelable: true });
                fileInput.dispatchEvent(inputEvt);
                
                console.log('[AutoPost] Injected ' + dt.files.length + ' files into file input');
                
                // Wait for images to visually upload to Facebook servers
                await sleep(Math.max(postImages.length * 4000, 5000)); 
            } else if (hasFiles && !fileInput) {
                console.warn('[AutoPost] No file input found, falling back to paste event');
                const imagePasteEvent = new ClipboardEvent('paste', {
                    clipboardData: dt,
                    bubbles: true,
                    cancelable: true
                });
                textBox.dispatchEvent(imagePasteEvent);
                await sleep(Math.max(postImages.length * 4000, 5000));
            }
        }

        // 4. Click Post (with wait for button to become enabled after image upload)
        const postBtnSelectors = [
            'div[role="button"][aria-label="Post"]',
            'div[role="button"][aria-label="Đăng"]'
        ];
        
        const findPostButton = () => {
            for (let sel of postBtnSelectors) {
                const btn = document.querySelector(sel);
                if (btn && btn.getAttribute('aria-disabled') !== 'true') return btn;
            }
            const btns = Array.from(document.querySelectorAll('div[role="button"]'));
            const maybeBtn = btns.find(b => (b.textContent === 'Đăng' || b.textContent === 'Post') && b.getAttribute('aria-disabled') !== 'true');
            return maybeBtn || null;
        };
        
        // Poll for Post button to become active (images may still be uploading)
        let postBtn = null;
        for (let attempt = 0; attempt < 30; attempt++) {
            postBtn = findPostButton();
            if (postBtn) break;
            await sleep(1000);
        }
        
        if (!postBtn) return { success: false, error: 'Không tìm thấy nút Đăng hoặc nút đang bị mờ (ảnh có thể tải chưa xong).' };
        
        // Gather existing post links before clicking Post
        const isPostUrl = (href) => {
            if (!href) return false;
            return href.includes('/posts/') || 
                   href.includes('/permalink/') || 
                   href.includes('multi_permalinks=') || 
                   href.includes('permalink.php');
        };
        const getPostLinks = () => {
            return Array.from(document.querySelectorAll('a'))
                .map(a => a.href)
                .filter(href => isPostUrl(href));
        };
        const existingLinks = new Set(getPostLinks());

        // === INTERCEPT FETCH: Bắt post_id từ GraphQL mutation response ===
        let capturedPostId = null;
        const originalFetch = window.fetch;
        const storyMutationNames = [
            'ComposerStoryCreateMutation',
            'useComposerStoryCreateMutation',
            'ComposerStoryPublishMutation',
            'story_create',
            'CreateGroupPost',
            'GroupsCometPostCreateMutation',
            'CometComposerSubmitMutation'
        ];
        
        window.fetch = async function(...args) {
            const response = await originalFetch.apply(this, args);
            
            try {
                const requestUrl = typeof args[0] === 'string' ? args[0] : (args[0]?.url || '');
                const requestBody = args[1]?.body || '';
                const bodyStr = typeof requestBody === 'string' ? requestBody : '';
                
                // Chỉ xử lý GraphQL requests liên quan đến tạo bài viết
                const isGraphQL = requestUrl.includes('/api/graphql') || requestUrl.includes('graphql');
                const isStoryCreate = isGraphQL && storyMutationNames.some(name => bodyStr.includes(name));
                
                if (isStoryCreate && !capturedPostId) {
                    console.log('[AutoPost] Detected story creation GraphQL request!');
                    const cloned = response.clone();
                    const text = await cloned.text();
                    
                    // Facebook trả về multi-line JSON (mỗi dòng là 1 JSON object)
                    const lines = text.split('\n').filter(l => l.trim());
                    for (const line of lines) {
                        try {
                            const json = JSON.parse(line);
                            
                            // Tìm post_id trong nhiều vị trí khác nhau
                            const findPostId = (obj, depth = 0) => {
                                if (!obj || typeof obj !== 'object' || depth > 8) return null;
                                
                                // Ưu tiên: story_create.story.id hoặc story.post_id
                                if (obj.story_create?.story?.id) return obj.story_create.story.id;
                                if (obj.story_create?.story?.legacy_story_hideable_id) return obj.story_create.story.legacy_story_hideable_id;
                                if (obj.story_create?.story?.post_id) return obj.story_create.story.post_id;
                                if (obj.story?.id) return obj.story.id;
                                if (obj.story?.post_id) return obj.story.post_id;
                                if (obj.id && obj.__typename === 'Story') return obj.id;
                                if (obj.post_id && obj.__typename) return obj.post_id;
                                
                                // Tìm trong data wrapper
                                if (obj.data) {
                                    const fromData = findPostId(obj.data, depth + 1);
                                    if (fromData) return fromData;
                                }
                                
                                // Tìm trong các key phổ biến
                                for (const key of Object.keys(obj)) {
                                    if (key === 'data' || key === 'extensions' || key === 'errors') continue;
                                    const val = obj[key];
                                    if (val && typeof val === 'object') {
                                        const found = findPostId(val, depth + 1);
                                        if (found) return found;
                                    }
                                }
                                return null;
                            };
                            
                            const postId = findPostId(json);
                            if (postId) {
                                capturedPostId = String(postId);
                                console.log('[AutoPost] Captured post_id from GraphQL response:', capturedPostId);
                                break;
                            }
                        } catch(e) {
                            // Bỏ qua dòng JSON không parse được
                        }
                    }
                }
            } catch (e) {
                // Không block request nếu có lỗi
            }
            
            return response;
        };

        postBtn.click();
        
        // 5. Wait for dialog to close and get link (supports both /permalink/ and /posts/ formats)
        let postLink = null;
         for (let i = 0; i < 60; i++) {
            await sleep(1000);
            
            // Strategy 0 (ưu tiên nhất): Dùng post_id từ GraphQL response interceptor
            if (!postLink && capturedPostId) {
                postLink = `https://www.facebook.com/groups/${postGroupId}/posts/${capturedPostId}`;
                console.log('[AutoPost] Built post link from intercepted post_id:', postLink);
                // Restore fetch ngay khi đã bắt được
                window.fetch = originalFetch;
            }

            if (!postLink) {
                 // Strategy 1: Tìm link trong toast hoặc link "Vừa xong" trên trang
                 const links = Array.from(document.querySelectorAll('a'));
                 
                 // 1a. Check Toast (role='alert')
                 const toastLinks = Array.from(document.querySelectorAll('[role="alert"] a, [data-testid="toast"] a'));
                 const viewPostLink = toastLinks.find(a => isPostUrl(a.href)) || 
                                      links.find(a => isPostUrl(a.href) && a.textContent.match(/Xem bài viết|View post|View Story/i));
                 if (viewPostLink) {
                     postLink = viewPostLink.href;
                     console.log('[AutoPost] Found post link via toast:', postLink);
                 }
                 
                 // 1b. Check "Vừa xong" / "Just now" timestamp link — use trimmed innerText
                 if (!postLink) {
                     const justNowLink = links.find(a => {
                         if (!isPostUrl(a.href)) return false;
                         const txt = (a.innerText || a.textContent || '').trim();
                         return txt === 'Vừa xong' || txt === 'Just now' || txt === 'Mới xong' ||
                                txt === '1 phút' || txt === '1 min' || txt === '1m' ||
                                txt === '2 phút' || txt === '2 min' || txt === '2m' ||
                                txt === '3 phút' || txt === '3 min' || txt === '3m' ||
                                txt.includes('vừa xong') || txt.includes('just now');
                     });
                     if (justNowLink) {
                         postLink = justNowLink.href;
                         console.log('[AutoPost] Found post link via timestamp:', postLink);
                     }
                 }
            }
            
            if (!postLink) {
                 // Strategy 2: Check current URL
                 if (isPostUrl(window.location.href)) {
                     postLink = window.location.href;
                     console.log('[AutoPost] Found post link via URL:', postLink);
                 }
            }

            if (!postLink) {
                 // Strategy 3: Check for brand NEW post links (not present before clicking)
                 const currentLinks = getPostLinks();
                 const newLink = currentLinks.find(href => href && !existingLinks.has(href));
                 if (newLink) {
                     postLink = newLink;
                     console.log('[AutoPost] Found post link via DOM diffing:', postLink);
                 }
            }

            if (!document.body.contains(postBtn) || postBtn.offsetParent === null) {
                if (!postLink) {
                    // Scroll lên đầu trang để Facebook render bài viết mới
                    window.scrollTo(0, 0);
                    console.log('[AutoPost] Dialog đã đóng, scroll lên đầu trang và chờ feed render...');
                    
                    // Chờ 3 giây cho feed render xong
                    await sleep(3000);
                    
                    // Retry 20 lần (chờ tối đa 20 giây cho toast/feed xuất hiện)
                    for (let retry = 0; retry < 20; retry++) {
                        await sleep(1000);
                        
                        // Check capturedPostId trước (từ fetch interceptor)
                        if (capturedPostId) {
                            postLink = `https://www.facebook.com/groups/${postGroupId}/posts/${capturedPostId}`;
                            console.log('[AutoPost Retry] Built link from intercepted post_id:', postLink);
                            break;
                        }
                        
                        const links = Array.from(document.querySelectorAll('a'));
                        
                        // Check toast (role='alert')
                        const toastLinks = Array.from(document.querySelectorAll('[role="alert"] a, [data-testid="toast"] a'));
                        const viewPostLink = toastLinks.find(a => isPostUrl(a.href)) || 
                                             links.find(a => isPostUrl(a.href) && a.textContent.match(/Xem bài viết|View post|View Story/i));
                        if (viewPostLink) { 
                            postLink = viewPostLink.href; 
                            console.log('[AutoPost] Found link via toast:', postLink);
                            break; 
                        }

                        // Check "Vừa xong" / "Just now" timestamp — use trimmed innerText for accuracy
                        const justNowLink = links.find(a => {
                            if (!isPostUrl(a.href)) return false;
                            const txt = (a.innerText || a.textContent || '').trim();
                            return txt === 'Vừa xong' || txt === 'Just now' || txt === 'Mới xong' ||
                                   txt === '1 phút' || txt === '1 min' || txt === '1m' ||
                                   txt === '2 phút' || txt === '2 min' || txt === '2m' ||
                                   txt === '3 phút' || txt === '3 min' || txt === '3m' ||
                                   txt.includes('vừa xong') || txt.includes('just now');
                        });
                        if (justNowLink) { 
                            postLink = justNowLink.href; 
                            console.log('[AutoPost] Found link via timestamp:', postLink);
                            break; 
                        }

                        // Check new links (DOM diffing)
                        const currentLinks = getPostLinks();
                        const newLink = currentLinks.find(href => href && !existingLinks.has(href));
                        if (newLink) {
                            postLink = newLink;
                            console.log('[AutoPost] Found link via DOM diffing:', postLink);
                            break;
                        }

                        // Check current URL (FB may redirect to the post)
                        if (isPostUrl(window.location.href)) {
                            postLink = window.location.href;
                            console.log('[AutoPost] Found link via URL redirect:', postLink);
                            break;
                        }
                        
                        // Mỗi 5 giây scroll lại lên đầu để trigger render
                        if (retry % 5 === 4) {
                            window.scrollTo(0, 0);
                        }
                    }
                }
                
                // Restore fetch trước khi return
                window.fetch = originalFetch;
                
                // Bài viết ĐÃ đăng thành công (dialog đã đóng) — trả về success dù có hay không có link
                return { success: true, postLink: postLink || null };
           }
           
           const errorMsg = Array.from(document.querySelectorAll('span')).find(s => s.textContent.includes('Something went wrong') || s.textContent.includes('Đã xảy ra lỗi'));
           if (errorMsg) {
                window.fetch = originalFetch;
                return { success: false, error: 'Facebook báo lỗi khi đăng bài.' };
           }
        }
        
        window.fetch = originalFetch;
        return { success: false, error: 'Quá thời gian chờ đăng bài.' };
      }
    });

    let finalPostLink = null;
    if (results && results[0] && results[0].result) {
        const res = results[0].result;
        if (!res.success) {
            throw new Error(res.error || 'Lỗi DOM');
        }
        if (res.postLink) {
            finalPostLink = res.postLink;
            // Normalize post link to: https://www.facebook.com/groups/<group_id>/posts/<post_id>
            try {
                if (finalPostLink.includes('multi_permalinks=')) {
                    const urlObj = new URL(finalPostLink);
                    const postId = urlObj.searchParams.get('multi_permalinks');
                    finalPostLink = `https://www.facebook.com/groups/${groupId}/posts/${postId}`;
                } else if (finalPostLink.includes('permalink.php')) {
                    const urlObj = new URL(finalPostLink);
                    const postId = urlObj.searchParams.get('story_fbid');
                    const id = urlObj.searchParams.get('id') || groupId;
                    finalPostLink = `https://www.facebook.com/groups/${id}/posts/${postId}`;
                } else {
                    let cleanUrl = finalPostLink.split('?')[0].split('#')[0];
                    if (cleanUrl.endsWith('/')) {
                        cleanUrl = cleanUrl.slice(0, -1);
                    }
                    cleanUrl = cleanUrl.replace(/\/permalink\//i, '/posts/');
                    finalPostLink = cleanUrl;
                }
            } catch (normalizeErr) {
                console.error('Failed to normalize post link:', normalizeErr);
            }
        }
    } else {
        throw new Error('Không thể chạy script trên tab Facebook');
    }

    // === RETRY: Nếu không lấy được link → Navigate về trang nhóm rồi quét lại ===
    if (!finalPostLink) {
        try {
            sendMessage(uiTabId, 'STATUS_UPDATE', { message: '🔍 Đang quay về nhóm để tìm link bài viết...' });
            const groupPageUrl = `https://www.facebook.com/groups/${groupId}/`;
            await chrome.tabs.update(fbTabId, { url: groupPageUrl });
            
            // Chờ trang load xong (tối đa 15 giây)
            await new Promise((resolve) => {
                let resolved = false;
                const timeout = setTimeout(() => { if (!resolved) { resolved = true; resolve(); } }, 15000);
                const listener = (tabId, changeInfo) => {
                    if (tabId === fbTabId && changeInfo.status === 'complete') {
                        chrome.tabs.onUpdated.removeListener(listener);
                        clearTimeout(timeout);
                        if (!resolved) { resolved = true; setTimeout(resolve, 3000); } // thêm 3s cho React render
                    }
                };
                chrome.tabs.onUpdated.addListener(listener);
            });
            
            // Chạy script thứ 2 để tìm link trên trang nhóm
            const retryResults = await chrome.scripting.executeScript({
                target: { tabId: fbTabId },
                func: () => {
                    const isPostUrl = (href) => {
                        if (!href) return false;
                        return href.includes('/posts/') || href.includes('/permalink/') || 
                               href.includes('multi_permalinks=') || href.includes('permalink.php');
                    };
                    
                    // Thử 10 lần, mỗi lần cách 1 giây
                    return new Promise(async (resolve) => {
                        for (let i = 0; i < 10; i++) {
                            await new Promise(r => setTimeout(r, 1000));
                            
                            const links = Array.from(document.querySelectorAll('a'));
                            
                            // Tìm link có timestamp "Vừa xong", "Just now", "1 phút", etc.
                            for (const a of links) {
                                if (!isPostUrl(a.href)) continue;
                                const txt = (a.innerText || a.textContent || '').trim().toLowerCase();
                                if (txt === 'vừa xong' || txt === 'just now' || txt === 'mới xong' ||
                                    txt === '1 phút' || txt === '1 min' || txt === '1m' ||
                                    txt === '2 phút' || txt === '2 min' || txt === '2m' ||
                                    txt === '3 phút' || txt === '3 min' || txt === '3m' ||
                                    txt === '4 phút' || txt === '4 min' || txt === '4m' ||
                                    txt === '5 phút' || txt === '5 min' || txt === '5m') {
                                    console.log('[AutoPost Retry] Found post link via timestamp:', a.href);
                                    resolve(a.href);
                                    return;
                                }
                            }
                            
                            // Tìm link bài viết đầu tiên trên trang (bài mới nhất)
                            const firstPostLink = links.find(a => {
                                if (!isPostUrl(a.href)) return false;
                                // Chỉ lấy link trong vùng nội dung chính (không phải sidebar)
                                const rect = a.getBoundingClientRect();
                                return rect.x > 200 && rect.y > 100 && rect.width > 0;
                            });
                            if (firstPostLink) {
                                console.log('[AutoPost Retry] Found first post link on group page:', firstPostLink.href);
                                resolve(firstPostLink.href);
                                return;
                            }
                        }
                        resolve(null);
                    });
                }
            });
            
            if (retryResults && retryResults[0] && retryResults[0].result) {
                let retryLink = retryResults[0].result;
                // Normalize
                try {
                    retryLink = retryLink.split('?')[0].split('#')[0];
                    if (retryLink.endsWith('/')) retryLink = retryLink.slice(0, -1);
                    retryLink = retryLink.replace(/\/permalink\//i, '/posts/');
                } catch(e) {}
                finalPostLink = retryLink;
                console.log('[AutoPost] Successfully found post link on retry:', finalPostLink);
            }
        } catch (retryErr) {
            console.error('[AutoPost] Retry to find link failed:', retryErr);
        }
    }

    sendMessage(uiTabId, 'STATUS_UPDATE', { message: `✅ Bước 3/3: Đăng bài DOM thành công!` });
    sendMessage(uiTabId, 'POST_SUCCESS', { groupId, postId: 'dom_post', postLink: finalPostLink });

  } catch (e) {
    throw e;
  }
}

// ========================================
// Mbasic Fallback (No doc_id needed)
// ========================================
async function postViaMbasic(uiTabId, fbTabId, groupId, content, images = []) {
  try {
    const mbasicUrl = `https://mbasic.facebook.com/groups/${groupId}`;
    
    // 1. Fetch group page
    const groupRes = await fetch(mbasicUrl, {
      headers: {
        'upgrade-insecure-requests': '1',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'
      }
    });
    
    if (!groupRes.ok) {
      throw new Error(`Không thể tải trang mbasic (HTTP ${groupRes.status})`);
    }
    
    const html = await groupRes.text();
    
    // 2. Parse form action
    const formMatch = html.match(/<form[^>]+action="(\/composer\/mbasic\/[^"]+)"[^>]*>/);
    if (!formMatch) {
      throw new Error('Không tìm thấy ô đăng bài mbasic. Tài khoản có thể bị chặn hoặc chưa tham gia nhóm.');
    }
    
    const actionUrl = 'https://mbasic.facebook.com' + formMatch[1].replace(/&amp;/g, '&');
    
    // 3. Parse hidden inputs
    const hiddenInputs = {};
    const inputRegex = /<input[^>]+type="hidden"[^>]+name="([^"]+)"[^>]+value="([^"]*)"/g;
    let match;
    while ((match = inputRegex.exec(html)) !== null) {
      hiddenInputs[match[1]] = match[2].replace(/&amp;/g, '&');
    }
    
    if (!hiddenInputs.fb_dtsg) {
      throw new Error('Không lấy được token fb_dtsg từ mbasic.');
    }
    
    const hasImages = Array.isArray(images) && images.length > 0;
    
    if (!hasImages) {
      sendMessage(uiTabId, 'STATUS_UPDATE', { message: '⚡ Mbasic: Đang gửi bài viết (chỉ có text)...' });
      
      const formData = new URLSearchParams();
      for (const [key, value] of Object.entries(hiddenInputs)) {
        formData.append(key, value);
      }
      formData.append('xc_message', content);
      formData.append('view_post', 'Đăng'); 
      
      const postRes = await fetch(actionUrl, {
        method: 'POST',
        headers: {
          'content-type': 'application/x-www-form-urlencoded',
          'origin': 'https://mbasic.facebook.com',
          'referer': mbasicUrl,
          'upgrade-insecure-requests': '1'
        },
        body: formData.toString()
      });
      
      if (!postRes.ok) {
        throw new Error(`Gửi bài mbasic thất bại (HTTP ${postRes.status})`);
      }
      
      const resultHtml = await postRes.text();
      if (resultHtml.includes('xc_message')) {
        throw new Error('Facebook từ chối bài viết qua mbasic.');
      }
      
      sendMessage(uiTabId, 'STATUS_UPDATE', { message: `✅ Đăng bài bằng Mobile Mode (Mbasic) thành công!` });
      sendMessage(uiTabId, 'POST_SUCCESS', { groupId, postId: 'mbasic_post', postLink: postRes.url });
      
    } else {
      // POSTING WITH IMAGES FLOW (MBASIC MULTI-STAGE COMPOSER)
      sendMessage(uiTabId, 'STATUS_UPDATE', { message: '⚡ Mbasic: Đang mở phần thêm ảnh...' });
      
      // Step 1: Tell composer we want to add photos by submitting view_photo button
      const viewPhotoMatch = html.match(/<input[^>]+name="view_photo"[^>]+value="([^"]+)"/);
      const viewPhotoValue = viewPhotoMatch ? viewPhotoMatch[1] : 'Ảnh';
      
      const stage1Data = new URLSearchParams();
      for (const [key, value] of Object.entries(hiddenInputs)) {
        stage1Data.append(key, value);
      }
      stage1Data.append('xc_message', content);
      stage1Data.append('view_photo', viewPhotoValue);
      
      const stage1Res = await fetch(actionUrl, {
        method: 'POST',
        headers: {
          'content-type': 'application/x-www-form-urlencoded',
          'origin': 'https://mbasic.facebook.com',
          'referer': mbasicUrl,
          'upgrade-insecure-requests': '1'
        },
        body: stage1Data.toString()
      });
      
      if (!stage1Res.ok) {
        throw new Error(`Mở phần upload ảnh mbasic thất bại (HTTP ${stage1Res.status})`);
      }
      
      const stage1Html = await stage1Res.text();
      
      // Step 2: Parse the upload form details
      const uploadFormMatch = stage1Html.match(/<form[^>]+action="(\/composer\/mbasic\/[^"]+)"[^>]*>/);
      if (!uploadFormMatch) {
        throw new Error('Không tìm thấy khung upload ảnh của mbasic.');
      }
      const uploadActionUrl = 'https://mbasic.facebook.com' + uploadFormMatch[1].replace(/&amp;/g, '&');
      
      const uploadHiddenInputs = {};
      let matchHidden;
      inputRegex.lastIndex = 0;
      while ((matchHidden = inputRegex.exec(stage1Html)) !== null) {
        uploadHiddenInputs[matchHidden[1]] = matchHidden[2].replace(/&amp;/g, '&');
      }
      
      const addPhotoDoneMatch = stage1Html.match(/<input[^>]+name="add_photo_done"[^>]+value="([^"]+)"/);
      const addPhotoDoneValue = addPhotoDoneMatch ? addPhotoDoneMatch[1] : 'Xem trước';
      
      sendMessage(uiTabId, 'STATUS_UPDATE', { message: `⚡ Mbasic: Đang chuẩn bị và tải lên ${images.length} ảnh...` });
      
      // Construct Multipart FormData for file upload
      const uploadFormData = new FormData();
      for (const [key, value] of Object.entries(uploadHiddenInputs)) {
        uploadFormData.append(key, value);
      }
      
      // Attach images to file1, file2, file3, etc.
      for (let i = 0; i < images.length; i++) {
        const b64 = images[i];
        let blob;
        let mime = 'image/jpeg';
        if (typeof b64 === 'string' && b64.startsWith('data:')) {
          const parts = b64.split(',');
          const byteString = atob(parts[1]);
          mime = parts[0].split(':')[1].split(';')[0];
          const ab = new ArrayBuffer(byteString.length);
          const ia = new Uint8Array(ab);
          for (let j = 0; j < byteString.length; j++) {
            ia[j] = byteString.charCodeAt(j);
          }
          blob = new Blob([ab], { type: mime });
        } else {
          // If not base64, try to fetch it
          const res = await fetch(b64);
          blob = await res.blob();
          mime = blob.type || 'image/jpeg';
        }
        const file = new File([blob], `image_${Date.now()}_${i}.jpg`, { type: mime });
        uploadFormData.append(`file${i + 1}`, file);
      }
      uploadFormData.append('add_photo_done', addPhotoDoneValue);
      
      const uploadRes = await fetch(uploadActionUrl, {
        method: 'POST',
        headers: {
          'origin': 'https://mbasic.facebook.com',
          'referer': stage1Res.url
        },
        body: uploadFormData
      });
      
      if (!uploadRes.ok) {
        throw new Error(`Upload ảnh lên mbasic thất bại (HTTP ${uploadRes.status})`);
      }
      
      const previewHtml = await uploadRes.text();
      
      // Step 3: Parse preview page and submit the final post
      const previewFormMatch = previewHtml.match(/<form[^>]+action="(\/composer\/mbasic\/[^"]+)"[^>]*>/);
      if (!previewFormMatch) {
        throw new Error('Không tìm thấy nút xác nhận đăng bài có ảnh mbasic.');
      }
      const finalActionUrl = 'https://mbasic.facebook.com' + previewFormMatch[1].replace(/&amp;/g, '&');
      
      const previewHiddenInputs = {};
      let matchFinal;
      inputRegex.lastIndex = 0;
      while ((matchFinal = inputRegex.exec(previewHtml)) !== null) {
        previewHiddenInputs[matchFinal[1]] = matchFinal[2].replace(/&amp;/g, '&');
      }
      
      const viewPostMatch = previewHtml.match(/<input[^>]+name="view_post"[^>]+value="([^"]+)"/);
      const viewPostValue = viewPostMatch ? viewPostMatch[1] : 'Đăng';
      
      sendMessage(uiTabId, 'STATUS_UPDATE', { message: '⚡ Mbasic: Đang hoàn tất đăng bài kèm ảnh...' });
      
      const finalFormData = new URLSearchParams();
      for (const [key, value] of Object.entries(previewHiddenInputs)) {
        finalFormData.append(key, value);
      }
      finalFormData.append('view_post', viewPostValue);
      
      const finalRes = await fetch(finalActionUrl, {
        method: 'POST',
        headers: {
          'content-type': 'application/x-www-form-urlencoded',
          'origin': 'https://mbasic.facebook.com',
          'referer': uploadRes.url,
          'upgrade-insecure-requests': '1'
        },
        body: finalFormData.toString()
      });
      
      if (!finalRes.ok) {
        throw new Error(`Xác nhận đăng bài có ảnh mbasic thất bại (HTTP ${finalRes.status})`);
      }
      
      const finalHtml = await finalRes.text();
      if (finalHtml.includes('xc_message')) {
        throw new Error('Facebook từ chối bài viết có ảnh qua mbasic.');
      }
      
      sendMessage(uiTabId, 'STATUS_UPDATE', { message: `✅ Đăng bài Mobile Mode (Mbasic) kèm ảnh thành công!` });
      sendMessage(uiTabId, 'POST_SUCCESS', { groupId, postId: 'mbasic_post_photo', postLink: finalRes.url });
    }
    
  } catch (error) {
    console.error('[Mbasic Error]', error);
    throw new Error('Đăng Mobile Mbasic thất bại: ' + error.message);
  }
}
